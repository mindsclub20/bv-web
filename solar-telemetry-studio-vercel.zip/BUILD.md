# Build guide
## Easiest: GitHub Actions (no local setup)
Push this folder to a GitHub repo -> Actions -> "Build desktop + Android" -> Run workflow.
Download artifacts: Windows .exe, macOS .dmg, Linux .AppImage, Android .apk (debug-signed).

## Local
- Windows/Mac/Linux:  npm install && npm run dist:desktop   (output: release/)
- Android (needs JDK 21 + Android SDK): npm install && npx cap add android && npm run android:apk
  APK: android/app/build/outputs/apk/debug/app-debug.apk
Notes: build a platform's installer on that platform. Live screen-capture OCR works on desktop only; Android WebView has no getDisplayMedia (Demo, Analysis, History, Export work).

## How to use the app
1. Casted phone: cast/mirror your phone to the PC (e.g. scrcpy, Vysor, Windows "Connect"), click SELECT MIRRORED ANDROID SCREEN and pick that window.
   Recorded video: record with any external app, click OPEN RECORDED VIDEO, scrub to a frame where the numbers show.
2. Draw 3 rectangles: Angle, Voltage, Current. The graph starts automatically after the 3rd.
3. A recorded video plays from 0:00 and the session saves + opens Export Center when it ends.

## Deploy to Vercel (web version)
1. Push this folder to GitHub, then Vercel -> Add New Project -> import the repo. Settings are read from `vercel.json` (Vite, `npm run build`, output `dist`). No environment variables needed.
2. Or CLI: `npm i -g vercel && vercel --prod`.
3. Open the deployed https URL in desktop Chrome/Edge: screen capture works over https. Phones cannot capture screens in a browser; use the recorded-video option there.
Note: web build loads OCR files from a CDN, so users need internet.

## Deploy the web version on Vercel
1. Repo root must contain package.json, vercel.json, src/ (not a zip file).
2. Vercel -> Add New -> Project -> import the repo. Framework preset: Vite (auto). Click Deploy.
3. No environment variables are required. Screen capture needs HTTPS, which Vercel provides.
Desktop (.exe) and Android (.apk) builds are separate: use the GitHub Actions workflow.
