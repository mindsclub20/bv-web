export const isElectron = (): boolean =>
  typeof navigator !== 'undefined' && /Electron/i.test(navigator.userAgent);

export const isNative = (): boolean =>
  typeof window !== 'undefined' &&
  Boolean((window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor?.isNativePlatform?.());

/** Bundled offline OCR assets exist only in packaged builds (see scripts/prepare-ocr-assets.mjs). */
export const useLocalOcrAssets = (): boolean => isElectron() || isNative();
