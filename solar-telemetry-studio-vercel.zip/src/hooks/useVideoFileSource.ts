import { useCallback, useEffect, useRef, useState } from 'react';

/** Lets the user load a screen recording made by any external app (OBS, Xbox Game Bar, scrcpy --record, phone recorder...). */
export function useVideoFileSource() {
  const [fileUrl, setFileUrl] = useState<string | null>(null);
  const [fileName, setFileName] = useState('');
  const urlRef = useRef<string | null>(null);

  const clearFile = useCallback(() => {
    if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    urlRef.current = null;
    setFileUrl(null);
    setFileName('');
  }, []);

  const openFile = useCallback((file: File) => {
    if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    const url = URL.createObjectURL(file);
    urlRef.current = url;
    setFileUrl(url);
    setFileName(file.name);
  }, []);

  useEffect(() => () => { if (urlRef.current) URL.revokeObjectURL(urlRef.current); }, []);

  return { fileUrl, fileName, openFile, clearFile };
}
