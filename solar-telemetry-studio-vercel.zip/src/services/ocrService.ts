import { createWorker, PSM, Worker } from 'tesseract.js';

import { useLocalOcrAssets } from '../utils/platform';

const LOCAL_BASE = new URL('./tesseract/', document.baseURI).href;

export const TESSERACT_LOCAL_CONFIG = {
  workerPath: LOCAL_BASE + 'worker.min.js',
  corePath: LOCAL_BASE + 'core',
  langPath: LOCAL_BASE + 'lang',
} as const;

export const TESSERACT_CDN_CONFIG = {
  workerPath: 'https://cdn.jsdelivr.net/npm/tesseract.js@7.0.0/dist/worker.min.js',
  corePath: 'https://cdn.jsdelivr.net/npm/tesseract.js-core@7.0.0',
  langPath: 'https://tessdata.projectnaptha.com/4.0.0',
} as const;

export interface OCRInitProgressCallback {
  (progress: number, status: string): void;
}

export interface OCRRecognizeResult {
  text: string;
  confidence: number;
}

class SolarOCRService {
  private worker: Worker | null = null;
  private initPromise: Promise<Worker> | null = null;
  private isTerminated = false;

  async initialize(
    onProgress?: OCRInitProgressCallback
  ): Promise<Worker> {
    if (this.worker) {
      return this.worker;
    }
    if (this.initPromise) {
      return this.initPromise;
    }

    this.isTerminated = false;
    this.initPromise = (async () => {
      try {
        onProgress?.(0.05, 'Loading Tesseract OCR worker...');
        const worker = await createWorker('eng', 1, {
          ...(useLocalOcrAssets() ? TESSERACT_LOCAL_CONFIG : TESSERACT_CDN_CONFIG),
          logger: (msg) => {
            if (typeof msg.progress === 'number') {
              onProgress?.(msg.progress, msg.status || 'Initializing OCR');
            }
          },
          errorHandler: (err) => {
            console.error('Tesseract worker error:', err);
          },
        });

        if (this.isTerminated) {
          await worker.terminate();
          throw new Error('OCR worker initialization cancelled.');
        }

        await worker.setParameters({
          tessedit_char_whitelist: '0123456789.-',
          tessedit_pageseg_mode: PSM.SINGLE_LINE,
        });

        this.worker = worker;
        onProgress?.(1, 'OCR engine ready');
        return worker;
      } catch (err) {
        this.worker = null;
        throw err instanceof Error
          ? err
          : new Error('Failed to initialize Tesseract OCR worker.');
      } finally {
        this.initPromise = null;
      }
    })();

    return this.initPromise;
  }

  async recognizeCanvas(canvas: HTMLCanvasElement): Promise<OCRRecognizeResult> {
    const worker = await this.initialize();
    const result = await worker.recognize(canvas);
    return {
      text: result.data.text ?? '',
      confidence: typeof result.data.confidence === 'number' ? result.data.confidence : 0,
    };
  }

  isReady(): boolean {
    return this.worker !== null;
  }

  async terminate(): Promise<void> {
    this.isTerminated = true;
    const activeWorker = this.worker;
    this.worker = null;
    this.initPromise = null;
    if (activeWorker) {
      try {
        await activeWorker.terminate();
      } catch {
        // Ignore cleanup errors on already-disposed worker
      }
    }
  }
}

export const ocrService = new SolarOCRService();
