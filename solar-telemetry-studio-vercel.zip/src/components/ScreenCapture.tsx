import React, { useEffect, useRef, useState } from 'react';
import { AlertTriangle, FileVideo, Monitor, Play, RefreshCw, StopCircle } from 'lucide-react';
import {
  CalibrationStepConfig,
  PartialCalibrationRegions,
} from '../types/calibration';
import { VideoDimensions } from '../hooks/useScreenCapture';
import { PixelRect } from '../utils/calculations';
import { CalibrationBanner } from './CalibrationBanner';
import { RegionSelector } from './RegionSelector';

interface ScreenCaptureProps {
  stream: MediaStream | null;
  fileUrl: string | null;
  fileName: string;
  onOpenVideoFile: (file: File) => void;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  videoDimensions: VideoDimensions | null;
  trackLabel: string;
  isSupported: boolean;
  isRequesting: boolean;
  error: string | null;
  onStartCapture: () => void;
  onStopCapture: () => void;
  onStartDemo: () => void;
  onVideoMetadata: (width: number, height: number) => void;
  regions: PartialCalibrationRegions;
  currentStepIndex: 0 | 1 | 2 | 3;
  activeStepConfig: CalibrationStepConfig | null;
  activeDraftRect: PixelRect | null;
  validationMessage: string | null;
  onPointerDown: (e: React.PointerEvent<HTMLDivElement>) => void;
  onPointerMove: (e: React.PointerEvent<HTMLDivElement>) => void;
  onPointerUp: (e: React.PointerEvent<HTMLDivElement>) => void;
  onUndo: () => void;
  onReset: () => void;
}

export const ScreenCapture: React.FC<ScreenCaptureProps> = ({
  stream,
  fileUrl,
  fileName,
  onOpenVideoFile,
  videoRef,
  videoDimensions,
  trackLabel,
  isSupported,
  isRequesting,
  error,
  onStartCapture,
  onStopCapture,
  onStartDemo,
  onVideoMetadata,
  regions,
  currentStepIndex,
  activeStepConfig,
  activeDraftRect,
  validationMessage,
  onPointerDown,
  onPointerMove,
  onPointerUp,
  onUndo,
  onReset,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(0);
  const hasSource = Boolean(stream || fileUrl);

  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    if (stream) {
      el.removeAttribute('src');
      el.srcObject = stream;
      void el.play().catch(() => {});
    } else if (fileUrl) {
      el.srcObject = null;
      el.src = fileUrl;
      el.pause(); // recorded video: wait on a frame so you can scrub to where the numbers are visible
    } else {
      el.srcObject = null;
      el.removeAttribute('src');
    }
  }, [stream, fileUrl, videoRef]);

  const videoFilePicker = (
    <>
      <input
        ref={fileInputRef}
        type="file"
        accept="video/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onOpenVideoFile(f);
          e.target.value = '';
        }}
      />
      <button
        type="button"
        onClick={() => fileInputRef.current?.click()}
        className="inline-flex items-center gap-2 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-5 py-2.5 text-sm font-semibold text-emerald-300 hover:bg-emerald-500/20 whitespace-nowrap"
      >
        <FileVideo className="h-4 w-4" aria-hidden="true" />
        <span>OPEN RECORDED VIDEO</span>
      </button>
    </>
  );

  const aspectRatio =
    videoDimensions && videoDimensions.width > 0 && videoDimensions.height > 0
      ? `${videoDimensions.width} / ${videoDimensions.height}`
      : '16 / 9';

  return (
    <div className="mx-auto max-w-6xl space-y-5 p-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-50">
            Screen Calibration
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Capture your mirrored Android solar monitoring display and select the Angle,
            Voltage, and Current numerical regions.
          </p>
        </div>

        {hasSource && (
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onStartCapture}
              className="inline-flex items-center gap-2 rounded-lg border border-[#253247] bg-[#111C2D] px-3.5 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 whitespace-nowrap"
            >
              <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Change Screen</span>
            </button>
            <button
              type="button"
              onClick={onStopCapture}
              className="inline-flex items-center gap-2 rounded-lg border border-rose-500/40 bg-rose-500/10 px-3.5 py-2 text-xs font-semibold text-rose-300 hover:bg-rose-500/20 whitespace-nowrap"
            >
              <StopCircle className="h-3.5 w-3.5" aria-hidden="true" />
              <span>{stream ? 'Disconnect Screen' : 'Close Video'}</span>
            </button>
          </div>
        )}
      </div>

      {error && (
        <div
          className="flex items-start gap-3 rounded-xl border border-rose-500/40 bg-rose-500/10 p-4 text-sm text-rose-200"
          role="alert"
        >
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" aria-hidden="true" />
          <div className="space-y-1">
            <p className="font-semibold text-rose-100">Screen Capture Unavailable</p>
            <p className="text-rose-200/90">{error}</p>
          </div>
        </div>
      )}

      {hasSource ? (
        <div className="space-y-4">
          <CalibrationBanner
            currentStepIndex={currentStepIndex}
            activeStepConfig={activeStepConfig}
            regions={regions}
            validationMessage={validationMessage}
            onUndo={onUndo}
            onReset={onReset}
          />

          <div className="rounded-xl border border-[#253247] bg-[#0D1524] p-4">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <span className="font-medium text-emerald-400">{stream ? 'Stream Connected' : 'Recorded Video Loaded'}</span>
                <span aria-hidden="true">·</span>
                <span className="truncate max-w-md text-slate-300">{stream ? trackLabel : fileName}</span>
              </div>
              {videoDimensions && (
                <span className="font-mono tabular-nums text-slate-400">
                  Native Resolution: {videoDimensions.width} × {videoDimensions.height}px
                </span>
              )}
            </div>

            {/* Aspect-ratio preserved stage */}
            <div className="flex justify-center rounded-lg border border-[#253247] bg-[#080D18] p-2">
              <div
                className="relative max-h-[68vh] w-auto overflow-hidden rounded border border-[#253247]"
                style={{ aspectRatio }}
              >
                <video
                  ref={videoRef}
                  autoPlay={Boolean(stream)}
                  playsInline
                  muted
                  onLoadedMetadata={(e) => {
                    const v = e.currentTarget;
                    onVideoMetadata(v.videoWidth, v.videoHeight);
                    setDuration(Number.isFinite(v.duration) ? v.duration : 0);
                  }}
                  onTimeUpdate={(e) => setPosition(e.currentTarget.currentTime)}
                  className="block h-full w-full object-contain"
                />
                <RegionSelector
                  regions={regions}
                  activeStepConfig={activeStepConfig}
                  activeDraftRect={activeDraftRect}
                  onPointerDown={onPointerDown}
                  onPointerMove={onPointerMove}
                  onPointerUp={onPointerUp}
                />
              </div>
            </div>

            {fileUrl && !stream && (
              <div className="mt-3 flex items-center gap-3 text-xs text-slate-400">
                <span>Scrub to a frame where the numbers are visible, then draw the 3 boxes:</span>
                <input
                  type="range"
                  min={0}
                  max={duration || 0}
                  step={0.1}
                  value={position}
                  onChange={(e) => {
                    const v = videoRef.current;
                    if (v) v.currentTime = Number(e.target.value);
                  }}
                  className="flex-1 accent-amber-500"
                  aria-label="Video position"
                />
                <span className="font-mono tabular-nums">{position.toFixed(1)}s / {duration.toFixed(1)}s</span>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-10 text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl border border-[#253247] bg-[#080D18] text-amber-400">
            <Monitor className="h-6 w-6" aria-hidden="true" />
          </div>
          <h2 className="mt-4 text-lg font-semibold text-slate-100">
            No Mirrored Screen Active
          </h2>
          <p className="mx-auto mt-2 max-w-lg text-sm leading-relaxed text-slate-400">
            Share the window showing your casted Android screen, or open a screen recording made with any external app. Once
            connected, drag three rectangles around the Angle (°), Voltage (V), and
            Current (A) numbers to begin automatic OCR telemetry.
          </p>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={onStartCapture}
              disabled={isRequesting || !isSupported}
              className="inline-flex items-center gap-2 rounded-lg bg-[#F59E0B] px-5 py-2.5 text-sm font-semibold text-slate-950 hover:bg-amber-400 disabled:opacity-50 whitespace-nowrap"
            >
              <Monitor className="h-4 w-4" aria-hidden="true" />
              <span>SELECT MIRRORED ANDROID SCREEN</span>
            </button>

            <button
              type="button"
              onClick={onStartDemo}
              className="inline-flex items-center gap-2 rounded-lg border border-cyan-500/40 bg-cyan-500/10 px-5 py-2.5 text-sm font-semibold text-cyan-300 hover:bg-cyan-500/20 whitespace-nowrap"
            >
              <Play className="h-4 w-4" aria-hidden="true" />
              <span>TEST WITH DEMO SIMULATOR</span>
            </button>

            {videoFilePicker}
          </div>
        </div>
      )}
    </div>
  );
};
