import React, { useEffect, useRef } from 'react';
import { AlertCircle, Monitor, Play } from 'lucide-react';
import { ExperimentMode } from '../types/experiment';
import {
  AppSettings,
  MetricReadState,
  OCRDiagnostics,
  RecordingStatus,
  SessionStatistics,
  TelemetrySample,
} from '../types/telemetry';
import { formatDuration } from '../utils/calculations';
import { ControlToolbar } from './ControlToolbar';
import { KPICard } from './KPICard';
import { AnglePowerScatterChart, LineTelemetryChart } from './TelemetryChart';

interface DashboardProps {
  mode: ExperimentMode | null;
  isPaused: boolean;
  samples: TelemetrySample[];
  angleState: MetricReadState;
  voltageState: MetricReadState;
  currentState: MetricReadState;
  currentPowerW: number | null;
  statistics: SessionStatistics;
  elapsedSeconds: number;
  settings: AppSettings;
  ocrDiagnostics: OCRDiagnostics;
  recordingStatus: RecordingStatus;
  recordingDurationSeconds: number;
  recordingError: string | null;
  stream: MediaStream | null;
  fileUrl?: string | null;
  onPause: () => void;
  onResume: () => void;
  onToggleInvert: () => void;
  onContrastChange: (val: number) => void;
  onRedrawBoxes: () => void;
  onStopAndExport: () => void;
  onSelectScreen: () => void;
  onStartDemo: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  mode,
  isPaused,
  samples,
  angleState,
  voltageState,
  currentState,
  currentPowerW,
  statistics,
  elapsedSeconds,
  settings,
  ocrDiagnostics,
  recordingStatus,
  recordingDurationSeconds,
  recordingError,
  stream,
  fileUrl,
  onPause,
  onResume,
  onToggleInvert,
  onContrastChange,
  onRedrawBoxes,
  onStopAndExport,
  onSelectScreen,
  onStartDemo,
}) => {
  const previewVideoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    const el = previewVideoRef.current;
    if (!el) return;
    if (stream) {
      el.srcObject = stream;
      void el.play().catch(() => {});
    } else if (fileUrl) {
      el.srcObject = null;
      el.src = fileUrl;
      void el.play().catch(() => {});
    } else {
      el.srcObject = null;
    }
  }, [stream, fileUrl]);

  if (!mode) {
    return (
      <div className="mx-auto max-w-5xl p-6">
        <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-10 text-center">
          <h1 className="text-xl font-bold text-slate-100">
            No Live Telemetry Session Running
          </h1>
          <p className="mx-auto mt-2 max-w-lg text-sm text-slate-400">
            Connect a mirrored Android display and calibrate the three readout boxes, or
            launch the Demo Simulator to stream live solar power calculations.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={onSelectScreen}
              className="inline-flex items-center gap-2 rounded-lg bg-[#F59E0B] px-5 py-2.5 text-sm font-semibold text-slate-950 hover:bg-amber-400 whitespace-nowrap"
            >
              <Monitor className="h-4 w-4" aria-hidden="true" />
              <span>SELECT MIRRORED ANDROID SCREEN</span>
            </button>
            <button
              type="button"
              onClick={onStartDemo}
              className="inline-flex items-center gap-2 rounded-lg border border-cyan-500/40 bg-cyan-500/10 px-5 py-2.5 text-sm font-semibold text-cyan-300 hover:bg-cyan-500/20 whitespace-nowrap"
            >
              <Play className="h-4 w-4" aria-hidden="true" />
              <span>TEST WITH DEMO SIMULATOR</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  const precision = settings.numericPrecision;
  const windowedSamples = samples.slice(-settings.chartWindowSamples);

  const getMetricTone = (state: MetricReadState) => {
    if (mode === 'demo') return 'simulated' as const;
    if (!state.isValid) return 'waiting' as const;
    return state.isFresh ? ('live' as const) : ('cached' as const);
  };

  const getMetricStatusText = (state: MetricReadState) => {
    if (mode === 'demo') return 'Simulated';
    if (!state.isValid) return 'Waiting';
    return state.isFresh ? 'Live OCR' : 'Retained';
  };

  return (
    <div className="mx-auto max-w-[1440px] space-y-5 p-6">
      {/* Mode Banner */}
      {mode === 'demo' && (
        <div
          className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-cyan-500/40 bg-cyan-500/10 px-4 py-2.5"
          role="status"
        >
          <span className="font-mono text-xs font-bold tracking-wider text-cyan-300">
            DEMO MODE — SIMULATED DATA
          </span>
          <span className="text-xs text-cyan-200/80">
            Mathematical cosine-irradiance solar simulation (peak target:{' '}
            {settings.demoPeakAngleDeg}°). Not physical hardware data.
          </span>
        </div>
      )}

      {/* Control Toolbar */}
      <ControlToolbar
        mode={mode}
        isPaused={isPaused}
        contrastThreshold={settings.contrastThreshold}
        invertDisplay={settings.invertDisplay}
        onPause={onPause}
        onResume={onResume}
        onToggleInvert={onToggleInvert}
        onContrastChange={onContrastChange}
        onRedrawBoxes={onRedrawBoxes}
        onStopAndExport={onStopAndExport}
      />

      {/* Five Premium KPI Cards */}
      <section
        aria-label="Live Telemetry KPI Cards"
        className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5"
      >
        <KPICard
          title="Tilt Angle"
          value={
            angleState.value !== null ? angleState.value.toFixed(1) : '—'
          }
          unit="°"
          description="Measured panel inclination"
          statusLabel={getMetricStatusText(angleState)}
          statusTone={getMetricTone(angleState)}
          accentColor="#F59E0B"
        />

        <KPICard
          title="Voltage"
          value={
            voltageState.value !== null
              ? voltageState.value.toFixed(precision)
              : '—'
          }
          unit="V"
          description="Panel terminal potential"
          statusLabel={getMetricStatusText(voltageState)}
          statusTone={getMetricTone(voltageState)}
          accentColor="#06B6D4"
        />

        <KPICard
          title="Current"
          value={
            currentState.value !== null
              ? currentState.value.toFixed(precision)
              : '—'
          }
          unit="A"
          description="Panel output amperage"
          statusLabel={getMetricStatusText(currentState)}
          statusTone={getMetricTone(currentState)}
          accentColor="#F43F5E"
        />

        <KPICard
          title="Power"
          value={
            currentPowerW !== null ? currentPowerW.toFixed(precision) : '—'
          }
          unit="W"
          description="Calculated P = V × I"
          statusLabel={
            currentPowerW !== null
              ? mode === 'demo'
                ? 'Calculated (Sim)'
                : 'Live P = V×I'
              : 'Waiting'
          }
          statusTone={
            currentPowerW !== null
              ? mode === 'demo'
                ? 'simulated'
                : 'live'
              : 'waiting'
          }
          accentColor="#10B981"
        />

        <KPICard
          title="Peak Observed Angle"
          value={
            statistics.peakObservedAngleDeg !== null
              ? statistics.peakObservedAngleDeg.toFixed(1)
              : '—'
          }
          unit="°"
          description={
            statistics.peakSample
              ? `At ${statistics.maxPowerW.toFixed(precision)} W max`
              : 'Awaiting peak sample'
          }
          statusLabel={statistics.peakSample ? 'Peak' : 'Waiting'}
          statusTone={statistics.peakSample ? 'peak' : 'waiting'}
          accentColor="#FACC15"
        />
      </section>

      {/* Session Statistics Bar */}
      <section
        aria-label="Session Statistics"
        className="grid grid-cols-2 gap-3 rounded-xl border border-[#253247] bg-[#0D1524] p-4 sm:grid-cols-3 lg:grid-cols-6"
      >
        <div>
          <p className="text-[11px] font-medium text-slate-400">Maximum Power</p>
          <p className="mt-1 font-mono text-base font-semibold tabular-nums text-emerald-400">
            {statistics.maxPowerW.toFixed(precision)} W
          </p>
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-400">Average Power</p>
          <p className="mt-1 font-mono text-base font-semibold tabular-nums text-slate-100">
            {statistics.averagePowerW.toFixed(precision)} W
          </p>
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-400">Average Voltage</p>
          <p className="mt-1 font-mono text-base font-semibold tabular-nums text-cyan-400">
            {statistics.averageVoltageV.toFixed(precision)} V
          </p>
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-400">Average Current</p>
          <p className="mt-1 font-mono text-base font-semibold tabular-nums text-rose-400">
            {statistics.averageCurrentA.toFixed(precision)} A
          </p>
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-400">Number of Samples</p>
          <p
            className="mt-1 font-mono text-base font-semibold tabular-nums text-slate-100"
            data-testid="sample-count"
          >
            {statistics.sampleCount}
          </p>
        </div>
        <div>
          <p className="text-[11px] font-medium text-slate-400">Session Duration</p>
          <p className="mt-1 font-mono text-base font-semibold tabular-nums text-slate-100">
            {formatDuration(elapsedSeconds)}
          </p>
        </div>
      </section>

      {/* Four Synchronized Live Charts */}
      <section
        aria-label="Synchronized Telemetry Charts"
        className="grid grid-cols-1 gap-4 lg:grid-cols-2"
      >
        <LineTelemetryChart
          title="Tilt Angle vs Time"
          unit="°"
          color="#F59E0B"
          data={windowedSamples}
          dataKey="angleDeg"
          seriesName="Tilt Angle"
          precision={1}
        />

        <LineTelemetryChart
          title="Voltage vs Time"
          unit="V"
          color="#06B6D4"
          data={windowedSamples}
          dataKey="voltageV"
          seriesName="Voltage"
          precision={precision}
        />

        <LineTelemetryChart
          title="Current vs Time"
          unit="A"
          color="#F43F5E"
          data={windowedSamples}
          dataKey="currentA"
          seriesName="Current"
          precision={precision}
        />

        <AnglePowerScatterChart
          data={samples}
          peakSample={statistics.peakSample}
          precision={precision}
        />
      </section>

      {/* Real-Mode OCR Engine Diagnostics & Mirrored Preview */}
      {mode === 'real' && (
        <section
          aria-label="OCR Engine Diagnostics and Stream Recording"
          className="grid grid-cols-1 gap-4 rounded-xl border border-[#253247] bg-[#0D1524] p-5 lg:grid-cols-3"
        >
          <div className="space-y-3 lg:col-span-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-sm font-semibold text-slate-100">
                OCR Engine & Recording Diagnostics
              </h3>
              <span className="font-mono text-xs text-slate-400">
                Interval: {settings.ocrIntervalMs}ms
              </span>
            </div>

            {ocrDiagnostics.lastError && (
              <div className="flex items-start gap-2 rounded-lg border border-rose-500/40 bg-rose-500/10 p-3 text-xs text-rose-200">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" />
                <span>{ocrDiagnostics.lastError}</span>
              </div>
            )}

            {recordingError && (
              <div className="flex items-start gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-xs text-amber-200">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
                <span>Recording: {recordingError}</span>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-5">
              <div className="rounded-lg border border-[#253247] bg-[#111C2D] p-3">
                <p className="text-[11px] text-slate-400">OCR Engine Status</p>
                <p className="mt-1 font-mono text-xs font-semibold uppercase text-cyan-300">
                  {ocrDiagnostics.engineStatus}
                </p>
              </div>
              <div className="rounded-lg border border-[#253247] bg-[#111C2D] p-3">
                <p className="text-[11px] text-slate-400">OCR Confidence</p>
                <p className="mt-1 font-mono text-xs font-semibold tabular-nums text-slate-100">
                  {ocrDiagnostics.averageConfidence}%
                </p>
              </div>
              <div className="rounded-lg border border-[#253247] bg-[#111C2D] p-3">
                <p className="text-[11px] text-slate-400">Processing Latency</p>
                <p className="mt-1 font-mono text-xs font-semibold tabular-nums text-slate-100">
                  {ocrDiagnostics.lastLatencyMs !== null
                    ? `${ocrDiagnostics.lastLatencyMs} ms`
                    : '—'}
                </p>
              </div>
              <div className="rounded-lg border border-[#253247] bg-[#111C2D] p-3">
                <p className="text-[11px] text-slate-400">Last Successful Read</p>
                <p className="mt-1 font-mono text-xs font-semibold tabular-nums text-slate-100">
                  {ocrDiagnostics.lastSuccessAt
                    ? new Date(ocrDiagnostics.lastSuccessAt).toLocaleTimeString()
                    : '—'}
                </p>
              </div>
              <div className="rounded-lg border border-[#253247] bg-[#111C2D] p-3">
                <p className="text-[11px] text-slate-400">Failed Samples</p>
                <p className="mt-1 font-mono text-xs font-semibold tabular-nums text-amber-400">
                  {ocrDiagnostics.failedSampleCount} / {ocrDiagnostics.totalSampleCount}
                </p>
              </div>
            </div>
          </div>

          {/* Mirrored Screen Preview Thumbnail */}
          <div className="rounded-lg border border-[#253247] bg-[#080D18] p-3">
            <div className="mb-2 flex items-center justify-between text-xs text-slate-400">
              <span>Live Source Feed</span>
              <span className="font-mono tabular-nums">
                {recordingStatus === 'recording'
                  ? `REC ${formatDuration(recordingDurationSeconds)}`
                  : recordingStatus}
              </span>
            </div>
            <video
              ref={previewVideoRef}
              autoPlay
              playsInline
              muted
              className="h-32 w-full rounded bg-black object-contain"
            />
          </div>
        </section>
      )}
    </div>
  );
};
