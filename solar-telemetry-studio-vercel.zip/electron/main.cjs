const { app, BrowserWindow, desktopCapturer, session, protocol, net, dialog, shell } = require('electron');
const path = require('path');
const { pathToFileURL } = require('url');

const DIST = path.join(__dirname, '..', 'dist');

// Custom origin so Web Workers + WASM (Tesseract OCR) work; file:// blocks them.
protocol.registerSchemesAsPrivileged([
  { scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, corsEnabled: true } },
]);

async function pickSource() {
  const sources = await desktopCapturer.getSources({ types: ['screen', 'window'], thumbnailSize: { width: 0, height: 0 } });
  if (sources.length === 0) return null;
  if (sources.length === 1) return sources[0];
  const shown = sources.slice(0, 8);
  const { response } = await dialog.showMessageBox({
    type: 'question',
    title: 'Select screen or window to capture',
    message: 'Which source contains the solar telemetry display?',
    buttons: [...shown.map((s) => s.name.slice(0, 60)), 'Cancel'],
    cancelId: shown.length,
    defaultId: 0,
  });
  return response === shown.length ? null : shown[response];
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1100,
    minHeight: 720,
    backgroundColor: '#080D18',
    autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true },
  });

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });

  win.loadURL('app://app/index.html');
}

app.whenReady().then(() => {
  protocol.handle('app', (request) => {
    const { pathname } = new URL(request.url);
    const rel = decodeURIComponent(pathname === '/' ? '/index.html' : pathname);
    const file = path.normalize(path.join(DIST, rel));
    if (!file.startsWith(DIST)) return new Response('Forbidden', { status: 403 });
    return net.fetch(pathToFileURL(file).toString());
  });

  // Lets navigator.mediaDevices.getDisplayMedia() work; user chooses the source.
  session.defaultSession.setDisplayMediaRequestHandler(
    async (_req, callback) => {
      try {
        const source = await pickSource();
        callback(source ? { video: source } : {});
      } catch {
        callback({});
      }
    },
    { useSystemPicker: true }
  );

  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
