// Copies Tesseract worker + WASM core and downloads English traineddata into public/tesseract
// so packaged apps (Windows/Android) run OCR fully offline. Needs internet once, at build time.
import fs from 'fs';
import path from 'path';
import https from 'https';

const out = path.resolve('public/tesseract');
fs.mkdirSync(path.join(out, 'core'), { recursive: true });
fs.mkdirSync(path.join(out, 'lang'), { recursive: true });

const nm = path.resolve('node_modules');
fs.copyFileSync(path.join(nm, 'tesseract.js/dist/worker.min.js'), path.join(out, 'worker.min.js'));
const coreDir = path.join(nm, 'tesseract.js-core');
for (const f of fs.readdirSync(coreDir)) {
  if (/^tesseract-core.*\.(js|wasm)$/.test(f)) fs.copyFileSync(path.join(coreDir, f), path.join(out, 'core', f));
}

const dest = path.join(out, 'lang', 'eng.traineddata.gz');
if (!fs.existsSync(dest)) {
  await new Promise((resolve, reject) => {
    https.get('https://tessdata.projectnaptha.com/4.0.0/eng.traineddata.gz', (res) => {
      if (res.statusCode !== 200) return reject(new Error('traineddata HTTP ' + res.statusCode));
      res.pipe(fs.createWriteStream(dest)).on('finish', resolve).on('error', reject);
    }).on('error', reject);
  });
}
console.log('OCR assets ready in', out);
