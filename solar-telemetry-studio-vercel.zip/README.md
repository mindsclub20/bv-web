# Solar Telemetry Studio
Reads angle, voltage and current from a casted phone screen or a recorded video using OCR, graphs power vs tilt angle, and exports CSV/PNG/video.
Web (Vercel): `npm install && npm run dev`. See BUILD.md for desktop, Android and Vercel.
