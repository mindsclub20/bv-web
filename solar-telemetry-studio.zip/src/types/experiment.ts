import { CalibrationRegions } from './calibration';
import { TelemetrySample } from './telemetry';

export type ExperimentMode = 'real' | 'demo';

export interface RecordingMetadata {
  hasRecording: boolean;
  mimeType: string | null;
  sizeBytes: number;
  durationSeconds: number;
  error: string | null;
}

export interface ExperimentSession {
  id: string;
  name: string;
  startedAtIso: string;
  endedAtIso: string | null;
  durationSeconds: number;
  mode: ExperimentMode;
  calibrationRegions: CalibrationRegions | null;
  samples: TelemetrySample[];
  peakPowerW: number;
  peakObservedAngleDeg: number | null;
  averagePowerW: number;
  averageVoltageV: number;
  averageCurrentA: number;
  recordingInfo: RecordingMetadata;
}

export interface AngleIntervalBin {
  label: string;
  minAngle: number;
  maxAngle: number;
  midpointAngle: number;
  sampleCount: number;
  measuredAveragePowerW: number | null;
  measuredMaxPowerW: number | null;
  interpolatedPowerW: number | null;
  isInterpolated: boolean;
}
