export type CalibrationMetric = 'angle' | 'voltage' | 'current';

export interface NormalizedRegion {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface CalibrationRegions {
  angle: NormalizedRegion;
  voltage: NormalizedRegion;
  current: NormalizedRegion;
}

export interface PartialCalibrationRegions {
  angle?: NormalizedRegion;
  voltage?: NormalizedRegion;
  current?: NormalizedRegion;
}

export interface CalibrationStepConfig {
  metric: CalibrationMetric;
  stepNumber: 1 | 2 | 3;
  label: string;
  unit: string;
  instruction: string;
  color: string;
}

export const CALIBRATION_STEPS: CalibrationStepConfig[] = [
  {
    metric: 'angle',
    stepNumber: 1,
    label: 'Tilt Angle',
    unit: '°',
    instruction: 'Click and drag a rectangle around the ANGLE number in degrees.',
    color: '#F59E0B',
  },
  {
    metric: 'voltage',
    stepNumber: 2,
    label: 'Voltage',
    unit: 'V',
    instruction: 'Click and drag a rectangle around the VOLTAGE number in volts.',
    color: '#06B6D4',
  },
  {
    metric: 'current',
    stepNumber: 3,
    label: 'Current',
    unit: 'A',
    instruction: 'Click and drag a rectangle around the CURRENT number in amperes.',
    color: '#F43F5E',
  },
];
