export type AppSection =
  | 'overview'
  | 'live-monitoring'
  | 'screen-calibration'
  | 'experiment-history'
  | 'performance-analysis'
  | 'reports-exports'
  | 'settings';

export type ConnectionStatus =
  | 'disconnected'
  | 'requesting'
  | 'connected'
  | 'calibrating'
  | 'monitoring'
  | 'paused'
  | 'demo'
  | 'error';

export type RecordingStatus =
  | 'idle'
  | 'recording'
  | 'stopped'
  | 'unsupported'
  | 'error';

export type OCREngineStatus =
  | 'idle'
  | 'initializing'
  | 'ready'
  | 'processing'
  | 'paused'
  | 'error';

export interface TelemetrySample {
  id: string;
  timestampMs: number;
  elapsedSeconds: number;
  angleDeg: number;
  voltageV: number;
  currentA: number;
  powerW: number;
}

export interface MetricReadState {
  value: number | null;
  isValid: boolean;
  isFresh: boolean;
  lastUpdatedAt: number | null;
  confidence: number;
  rawText: string;
}

export interface OCRDiagnostics {
  engineStatus: OCREngineStatus;
  initProgress: number;
  initMessage: string;
  lastLatencyMs: number | null;
  lastSuccessAt: number | null;
  failedSampleCount: number;
  totalSampleCount: number;
  averageConfidence: number;
  lastError: string | null;
}

export interface SessionStatistics {
  sampleCount: number;
  maxPowerW: number;
  minPowerW: number;
  averagePowerW: number;
  powerVariationW: number;
  averageVoltageV: number;
  averageCurrentA: number;
  peakObservedAngleDeg: number | null;
  peakSample: TelemetrySample | null;
  durationSeconds: number;
}

export interface AppSettings {
  ocrIntervalMs: number;
  contrastThreshold: number;
  invertDisplay: boolean;
  chartWindowSamples: number;
  numericPrecision: number;
  demoPeakAngleDeg: number;
  angleBinIntervalDeg: number;
}

export const DEFAULT_APP_SETTINGS: AppSettings = {
  ocrIntervalMs: 600,
  contrastThreshold: 128,
  invertDisplay: false,
  chartWindowSamples: 120,
  numericPrecision: 2,
  demoPeakAngleDeg: 34,
  angleBinIntervalDeg: 10,
};
