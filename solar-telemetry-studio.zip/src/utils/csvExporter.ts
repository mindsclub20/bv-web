import { TelemetrySample } from '../types/telemetry';

const CSV_HEADERS = ['Time_s', 'Angle_deg', 'Voltage_V', 'Current_A', 'Power_W'];

export function escapeCsvField(value: string | number): string {
  const str = String(value);
  if (/[",\r\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * Generates RFC 4180 compliant CSV log with exact required headers:
 * Time_s,Angle_deg,Voltage_V,Current_A,Power_W
 */
export function generateTelemetryCsv(
  samples: TelemetrySample[],
  precision: number = 3
): string {
  const safePrecision = Math.max(0, Math.min(6, precision));
  const lines: string[] = [CSV_HEADERS.join(',')];

  for (const s of samples) {
    const row = [
      s.elapsedSeconds.toFixed(2),
      s.angleDeg.toFixed(safePrecision),
      s.voltageV.toFixed(safePrecision),
      s.currentA.toFixed(safePrecision),
      s.powerW.toFixed(safePrecision),
    ].map(escapeCsvField);

    lines.push(row.join(','));
  }

  return lines.join('\r\n');
}

export function downloadCsvBlob(csvContent: string, filename: string = 'solar_panel_log.csv'): void {
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
