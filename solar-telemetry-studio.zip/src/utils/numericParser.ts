export interface ParseNumericOptions {
  min?: number;
  max?: number;
}

const NUMERIC_PATTERN = /-?\d+\.?\d*/;

/**
 * Extracts and validates a finite numerical reading from raw OCR text.
 * Rejects empty strings, NaN, Infinity, standalone signs, and out-of-range values.
 */
export function parseNumericReading(
  rawText: string,
  options: ParseNumericOptions = {}
): number | null {
  if (!rawText || typeof rawText !== 'string') {
    return null;
  }

  const trimmed = rawText.trim();
  if (!trimmed) {
    return null;
  }

  // Reject explicit non-numeric tokens like NaN or Infinity
  if (/nan|infinity|inf/i.test(trimmed)) {
    return null;
  }

  // Normalize common OCR comma decimals or whitespace
  const normalized = trimmed.replace(/,/g, '.').replace(/\s+/g, '');
  const match = normalized.match(NUMERIC_PATTERN);
  if (!match) {
    return null;
  }

  const candidate = match[0];
  if (candidate === '-' || candidate === '.' || candidate === '-.') {
    return null;
  }

  const cleanCandidate = candidate.endsWith('.')
    ? candidate.slice(0, -1)
    : candidate;

  const parsed = Number(cleanCandidate);
  if (!Number.isFinite(parsed) || Number.isNaN(parsed)) {
    return null;
  }

  if (options.min !== undefined && parsed < options.min) {
    return null;
  }
  if (options.max !== undefined && parsed > options.max) {
    return null;
  }

  return parsed;
}
