import test from 'node:test';
import assert from 'node:assert/strict';
import { parseNumericReading } from './numericParser';
import {
  calculatePower,
  computeSessionStatistics,
  computeAngleIntervalAnalysis,
  normalizeRegion,
  denormalizeRegion,
  validateMinRegionSize,
} from './calculations';
import { processGrayscaleContrastBinarize } from './imageProcessing';
import { escapeCsvField, generateTelemetryCsv } from './csvExporter';
import { TelemetrySample } from '../types/telemetry';

test('parseNumericReading extracts valid numeric values and rejects invalid inputs', () => {
  assert.equal(parseNumericReading('24.85'), 24.85);
  assert.equal(parseNumericReading('  -12.4  \n'), -12.4);
  assert.equal(parseNumericReading('0'), 0);
  assert.equal(parseNumericReading('18,75'), 18.75);
  assert.equal(parseNumericReading('36.'), 36);

  // Reject invalid readings
  assert.equal(parseNumericReading(''), null);
  assert.equal(parseNumericReading('   '), null);
  assert.equal(parseNumericReading('NaN'), null);
  assert.equal(parseNumericReading('Infinity'), null);
  assert.equal(parseNumericReading('-'), null);
  assert.equal(parseNumericReading('-.'), null);
  assert.equal(parseNumericReading('ERR'), null);

  // Range clamping
  assert.equal(parseNumericReading('120', { min: 0, max: 90 }), null);
  assert.equal(parseNumericReading('45', { min: 0, max: 90 }), 45);
});

test('calculatePower computes Voltage * Current accurately', () => {
  assert.equal(calculatePower(18.5, 2.0), 37.0);
  assert.equal(calculatePower(0, 3.2), 0);
  assert.equal(calculatePower(Number.NaN, 2.0), 0);
});

test('computeSessionStatistics identifies peak power and corresponding angle', () => {
  const samples: TelemetrySample[] = [
    { id: '1', timestampMs: 1000, elapsedSeconds: 0.6, angleDeg: 15, voltageV: 17.5, currentA: 1.8, powerW: 31.5 },
    { id: '2', timestampMs: 2000, elapsedSeconds: 1.2, angleDeg: 34, voltageV: 19.2, currentA: 2.5, powerW: 48.0 },
    { id: '3', timestampMs: 3000, elapsedSeconds: 1.8, angleDeg: 55, voltageV: 18.0, currentA: 1.9, powerW: 34.2 },
  ];

  const stats = computeSessionStatistics(samples);
  assert.equal(stats.sampleCount, 3);
  assert.equal(stats.maxPowerW, 48.0);
  assert.equal(stats.minPowerW, 31.5);
  assert.equal(stats.peakObservedAngleDeg, 34);
  assert.ok(Math.abs(stats.powerVariationW - 16.5) < 1e-6);
  assert.ok(Math.abs(stats.averagePowerW - 37.9) < 1e-6);
  assert.equal(stats.durationSeconds, 1.8);

  const emptyStats = computeSessionStatistics([]);
  assert.equal(emptyStats.sampleCount, 0);
  assert.equal(emptyStats.peakObservedAngleDeg, null);
});

test('computeAngleIntervalAnalysis bins measured samples and marks interpolated gaps', () => {
  const samples: TelemetrySample[] = [
    { id: '1', timestampMs: 1000, elapsedSeconds: 1, angleDeg: 5, voltageV: 18, currentA: 1.5, powerW: 27 },
    { id: '2', timestampMs: 2000, elapsedSeconds: 2, angleDeg: 25, voltageV: 19, currentA: 2.0, powerW: 38 },
  ];

  const bins = computeAngleIntervalAnalysis(samples, 10, 1);
  assert.equal(bins.length, 9);
  // 0-10 deg measured
  assert.equal(bins[0].measuredAveragePowerW, 27);
  assert.equal(bins[0].isInterpolated, false);
  // 10-20 deg interpolated midpoint between 27 and 38 => 32.5
  assert.equal(bins[1].measuredAveragePowerW, null);
  assert.equal(bins[1].isInterpolated, true);
  assert.equal(bins[1].interpolatedPowerW, 32.5);
  // 20-30 deg measured
  assert.equal(bins[2].measuredAveragePowerW, 38);
  assert.equal(bins[2].isInterpolated, false);
  // 30-40 deg beyond measured range -> neither measured nor interpolated
  assert.equal(bins[3].measuredAveragePowerW, null);
  assert.equal(bins[3].interpolatedPowerW, null);
});

test('normalized calibration coordinates preserve region accuracy across resolutions', () => {
  assert.equal(validateMinRegionSize(9, 12), false);
  assert.equal(validateMinRegionSize(12, 9), false);
  assert.equal(validateMinRegionSize(10, 10), true);

  const normalized = normalizeRegion({ x: 100, y: 200, width: 150, height: 50 }, 500, 1000);
  assert.deepEqual(normalized, { x: 0.2, y: 0.2, width: 0.3, height: 0.05 });

  // Denormalize onto a 1080x2160 video stream
  const videoRect = denormalizeRegion(normalized, 1080, 2160);
  assert.deepEqual(videoRect, { x: 216, y: 432, width: 324, height: 108 });
});

test('processGrayscaleContrastBinarize binarizes and respects dark/light invert flag', () => {
  // Two pixels: dark (10,10,10) and bright (240,240,240)
  const pixels = new Uint8ClampedArray([
    10, 10, 10, 255,
    240, 240, 240, 255,
  ]);
  processGrayscaleContrastBinarize(pixels, 128, false);
  assert.equal(pixels[0], 0);
  assert.equal(pixels[4], 255);

  const invertedPixels = new Uint8ClampedArray([
    10, 10, 10, 255,
    240, 240, 240, 255,
  ]);
  processGrayscaleContrastBinarize(invertedPixels, 128, true);
  assert.equal(invertedPixels[0], 255);
  assert.equal(invertedPixels[4], 0);
});

test('generateTelemetryCsv produces exact headers and escapes special characters', () => {
  assert.equal(escapeCsvField('a,b'), '"a,b"');
  assert.equal(escapeCsvField('say "hi"'), '"say ""hi"""');

  const csv = generateTelemetryCsv(
    [
      {
        id: '1',
        timestampMs: 1000,
        elapsedSeconds: 0.6,
        angleDeg: 30,
        voltageV: 18.5,
        currentA: 2.2,
        powerW: 40.7,
      },
    ],
    2
  );
  const lines = csv.split('\r\n');
  assert.equal(lines[0], 'Time_s,Angle_deg,Voltage_V,Current_A,Power_W');
  assert.equal(lines[1], '0.60,30.00,18.50,2.20,40.70');
});
