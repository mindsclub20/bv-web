import { ExperimentSession } from '../types/experiment';
import { TelemetrySample } from '../types/telemetry';
import { computeSessionStatistics, formatDuration } from './calculations';

interface ChartBounds {
  x: number;
  y: number;
  w: number;
  h: number;
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawLineChartPanel(
  ctx: CanvasRenderingContext2D,
  bounds: ChartBounds,
  title: string,
  unit: string,
  color: string,
  samples: TelemetrySample[],
  getX: (s: TelemetrySample) => number,
  getY: (s: TelemetrySample) => number,
  xLabel: string
) {
  const { x, y, w, h } = bounds;
  ctx.fillStyle = '#111C2D';
  ctx.strokeStyle = '#253247';
  ctx.lineWidth = 2;
  drawRoundedRect(ctx, x, y, w, h, 14);
  ctx.fill();
  ctx.stroke();

  // Header
  ctx.fillStyle = '#F8FAFC';
  ctx.font = '600 22px "IBM Plex Sans", system-ui, sans-serif';
  ctx.fillText(title, x + 28, y + 40);

  ctx.fillStyle = '#94A3B8';
  ctx.font = '500 16px "JetBrains Mono", monospace';
  ctx.textAlign = 'right';
  ctx.fillText(unit, x + w - 28, y + 40);
  ctx.textAlign = 'left';

  const padL = 76;
  const padR = 32;
  const padT = 68;
  const padB = 56;
  const plotX = x + padL;
  const plotY = y + padT;
  const plotW = w - padL - padR;
  const plotH = h - padT - padB;

  if (samples.length === 0) {
    ctx.fillStyle = '#64748B';
    ctx.font = '500 18px "IBM Plex Sans", system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('No telemetry samples recorded', x + w / 2, y + h / 2 + 10);
    ctx.textAlign = 'left';
    return;
  }

  const xs = samples.map(getX);
  const ys = samples.map(getY);
  let minX = Math.min(...xs);
  let maxX = Math.max(...xs);
  if (maxX === minX) maxX = minX + 1;

  let minY = Math.min(...ys);
  let maxY = Math.max(...ys);
  if (maxY === minY) {
    minY = Math.max(0, minY - 1);
    maxY = maxY + 1;
  } else {
    const padY = (maxY - minY) * 0.1;
    minY = Math.max(0, minY - padY);
    maxY = maxY + padY;
  }

  // Gridlines
  const yTicks = 4;
  ctx.strokeStyle = '#1E293B';
  ctx.lineWidth = 1;
  ctx.fillStyle = '#64748B';
  ctx.font = '400 14px "JetBrains Mono", monospace';

  for (let i = 0; i <= yTicks; i++) {
    const ratio = i / yTicks;
    const gy = plotY + plotH - ratio * plotH;
    const val = minY + ratio * (maxY - minY);
    ctx.beginPath();
    ctx.moveTo(plotX, gy);
    ctx.lineTo(plotX + plotW, gy);
    ctx.stroke();

    ctx.textAlign = 'right';
    ctx.fillText(val.toFixed(1), plotX - 10, gy + 5);
  }

  // X ticks
  const xTicks = 4;
  ctx.textAlign = 'center';
  for (let i = 0; i <= xTicks; i++) {
    const ratio = i / xTicks;
    const gx = plotX + ratio * plotW;
    const val = minX + ratio * (maxX - minX);
    ctx.fillText(`${val.toFixed(0)}s`, gx, plotY + plotH + 24);
  }
  ctx.fillStyle = '#94A3B8';
  ctx.fillText(xLabel, plotX + plotW / 2, plotY + plotH + 45);
  ctx.textAlign = 'left';

  // Plot line
  ctx.strokeStyle = color;
  ctx.lineWidth = 3;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  ctx.beginPath();
  samples.forEach((s, idx) => {
    const px = plotX + ((getX(s) - minX) / (maxX - minX)) * plotW;
    const py = plotY + plotH - ((getY(s) - minY) / (maxY - minY)) * plotH;
    if (idx === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  });
  ctx.stroke();
}

function drawScatterPowerPanel(
  ctx: CanvasRenderingContext2D,
  bounds: ChartBounds,
  samples: TelemetrySample[],
  maxPowerW: number,
  peakAngleDeg: number | null
) {
  const { x, y, w, h } = bounds;
  ctx.fillStyle = '#111C2D';
  ctx.strokeStyle = '#253247';
  ctx.lineWidth = 2;
  drawRoundedRect(ctx, x, y, w, h, 14);
  ctx.fill();
  ctx.stroke();

  const titleSuffix =
    peakAngleDeg !== null
      ? `Peak: ${maxPowerW.toFixed(2)} W @ ${peakAngleDeg.toFixed(1)}°`
      : 'No peak observed';

  ctx.fillStyle = '#F8FAFC';
  ctx.font = '600 22px "IBM Plex Sans", system-ui, sans-serif';
  ctx.fillText('Tilt Angle vs Power', x + 28, y + 40);

  ctx.fillStyle = '#FACC15';
  ctx.font = '600 16px "JetBrains Mono", monospace';
  ctx.textAlign = 'right';
  ctx.fillText(titleSuffix, x + w - 28, y + 40);
  ctx.textAlign = 'left';

  const padL = 76;
  const padR = 32;
  const padT = 68;
  const padB = 56;
  const plotX = x + padL;
  const plotY = y + padT;
  const plotW = w - padL - padR;
  const plotH = h - padT - padB;

  if (samples.length === 0) {
    ctx.fillStyle = '#64748B';
    ctx.font = '500 18px "IBM Plex Sans", system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('No telemetry samples recorded', x + w / 2, y + h / 2 + 10);
    ctx.textAlign = 'left';
    return;
  }

  const angles = samples.map((s) => s.angleDeg);
  const powers = samples.map((s) => s.powerW);
  let minX = Math.min(...angles);
  let maxX = Math.max(...angles);
  if (maxX === minX) {
    minX = Math.max(0, minX - 5);
    maxX = maxX + 5;
  }
  let minY = 0;
  let maxY = Math.max(...powers) * 1.12;
  if (maxY <= 0) maxY = 10;

  ctx.strokeStyle = '#1E293B';
  ctx.lineWidth = 1;
  ctx.fillStyle = '#64748B';
  ctx.font = '400 14px "JetBrains Mono", monospace';

  for (let i = 0; i <= 4; i++) {
    const ratio = i / 4;
    const gy = plotY + plotH - ratio * plotH;
    const val = minY + ratio * (maxY - minY);
    ctx.beginPath();
    ctx.moveTo(plotX, gy);
    ctx.lineTo(plotX + plotW, gy);
    ctx.stroke();
    ctx.textAlign = 'right';
    ctx.fillText(val.toFixed(1), plotX - 10, gy + 5);
  }

  ctx.textAlign = 'center';
  for (let i = 0; i <= 4; i++) {
    const ratio = i / 4;
    const gx = plotX + ratio * plotW;
    const val = minX + ratio * (maxX - minX);
    ctx.fillText(`${val.toFixed(0)}°`, gx, plotY + plotH + 24);
  }
  ctx.fillStyle = '#94A3B8';
  ctx.fillText('Solar Panel Tilt Angle (°)', plotX + plotW / 2, plotY + plotH + 45);
  ctx.textAlign = 'left';

  let peakSample: TelemetrySample | null = null;
  for (const s of samples) {
    if (!peakSample || s.powerW > peakSample.powerW) {
      peakSample = s;
    }
    const px = plotX + ((s.angleDeg - minX) / (maxX - minX)) * plotW;
    const py = plotY + plotH - ((s.powerW - minY) / (maxY - minY)) * plotH;
    ctx.fillStyle = 'rgba(16, 185, 129, 0.75)';
    ctx.beginPath();
    ctx.arc(px, py, 5, 0, Math.PI * 2);
    ctx.fill();
  }

  if (peakSample) {
    const px = plotX + ((peakSample.angleDeg - minX) / (maxX - minX)) * plotW;
    const py = plotY + plotH - ((peakSample.powerW - minY) / (maxY - minY)) * plotH;
    ctx.strokeStyle = '#FACC15';
    ctx.lineWidth = 3;
    ctx.fillStyle = '#FACC15';
    ctx.beginPath();
    ctx.arc(px, py, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(px, py, 16, 0, Math.PI * 2);
    ctx.stroke();
  }
}

/**
 * Generates a high-resolution 2400x1560 PNG report containing session metadata,
 * summary KPIs, and all four telemetry charts.
 */
export async function generateReportPngBlob(
  session: ExperimentSession,
  precision: number = 2
): Promise<Blob> {
  if (document.fonts?.ready) {
    await document.fonts.ready;
  }
  await new Promise((resolve) => requestAnimationFrame(() => resolve(undefined)));

  const width = 2400;
  const height = 1560;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Could not initialize 2D canvas context for PNG report.');
  }

  const stats = computeSessionStatistics(session.samples);

  // Background
  ctx.fillStyle = '#080D18';
  ctx.fillRect(0, 0, width, height);

  // Top Header Band
  ctx.fillStyle = '#0D1524';
  ctx.fillRect(0, 0, width, 150);
  ctx.strokeStyle = '#253247';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, 150);
  ctx.lineTo(width, 150);
  ctx.stroke();

  ctx.fillStyle = '#F59E0B';
  ctx.font = '700 20px "JetBrains Mono", monospace';
  ctx.fillText('SOLAR TELEMETRY STUDIO', 64, 52);

  ctx.fillStyle = '#F8FAFC';
  ctx.font = '700 36px "IBM Plex Sans", system-ui, sans-serif';
  ctx.fillText(session.name, 64, 104);

  const sessionDate = new Date(session.startedAtIso).toLocaleString();
  const modeLabel = session.mode === 'demo' ? 'DEMO MODE — SIMULATED DATA' : 'LIVE HARDWARE CAPTURE';

  ctx.textAlign = 'right';
  ctx.fillStyle = session.mode === 'demo' ? '#F59E0B' : '#10B981';
  ctx.font = '600 18px "JetBrains Mono", monospace';
  ctx.fillText(modeLabel, width - 64, 52);

  ctx.fillStyle = '#94A3B8';
  ctx.font = '500 20px "IBM Plex Sans", system-ui, sans-serif';
  ctx.fillText(
    `Date: ${sessionDate}  ·  Duration: ${formatDuration(session.durationSeconds)}  ·  Samples: ${stats.sampleCount}`,
    width - 64,
    102
  );
  ctx.textAlign = 'left';

  // Summary KPI Row (4 cards)
  const kpis = [
    {
      label: 'MAXIMUM MEASURED POWER',
      value: `${stats.maxPowerW.toFixed(precision)} W`,
      color: '#10B981',
    },
    {
      label: 'OPTIMAL OBSERVED ANGLE',
      value:
        stats.peakObservedAngleDeg !== null
          ? `${stats.peakObservedAngleDeg.toFixed(1)}°`
          : '—',
      color: '#FACC15',
    },
    {
      label: 'AVERAGE VOLTAGE',
      value: `${stats.averageVoltageV.toFixed(precision)} V`,
      color: '#06B6D4',
    },
    {
      label: 'AVERAGE CURRENT',
      value: `${stats.averageCurrentA.toFixed(precision)} A`,
      color: '#F43F5E',
    },
  ];

  const cardGap = 28;
  const cardW = (width - 128 - cardGap * 3) / 4;
  kpis.forEach((kpi, i) => {
    const cx = 64 + i * (cardW + cardGap);
    const cy = 186;
    ctx.fillStyle = '#111C2D';
    ctx.strokeStyle = '#253247';
    ctx.lineWidth = 2;
    drawRoundedRect(ctx, cx, cy, cardW, 130, 14);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#94A3B8';
    ctx.font = '600 16px "IBM Plex Sans", system-ui, sans-serif';
    ctx.fillText(kpi.label, cx + 28, cy + 44);

    ctx.fillStyle = kpi.color;
    ctx.font = '700 44px "JetBrains Mono", monospace';
    ctx.fillText(kpi.value, cx + 28, cy + 102);
  });

  // Four Charts Grid (2 x 2)
  const gridTop = 352;
  const chartGap = 32;
  const chartW = (width - 128 - chartGap) / 2;
  const chartH = 540;

  drawLineChartPanel(
    ctx,
    { x: 64, y: gridTop, w: chartW, h: chartH },
    'Tilt Angle vs Time',
    'DEGREES (°)',
    '#F59E0B',
    session.samples,
    (s) => s.elapsedSeconds,
    (s) => s.angleDeg,
    'Elapsed Time (s)'
  );

  drawLineChartPanel(
    ctx,
    { x: 64 + chartW + chartGap, y: gridTop, w: chartW, h: chartH },
    'Voltage vs Time',
    'VOLTS (V)',
    '#06B6D4',
    session.samples,
    (s) => s.elapsedSeconds,
    (s) => s.voltageV,
    'Elapsed Time (s)'
  );

  drawLineChartPanel(
    ctx,
    { x: 64, y: gridTop + chartH + chartGap, w: chartW, h: chartH },
    'Current vs Time',
    'AMPERES (A)',
    '#F43F5E',
    session.samples,
    (s) => s.elapsedSeconds,
    (s) => s.currentA,
    'Elapsed Time (s)'
  );

  drawScatterPowerPanel(
    ctx,
    { x: 64 + chartW + chartGap, y: gridTop + chartH + chartGap, w: chartW, h: chartH },
    session.samples,
    stats.maxPowerW,
    stats.peakObservedAngleDeg
  );

  // Footer note
  ctx.fillStyle = '#64748B';
  ctx.font = '400 16px "IBM Plex Sans", system-ui, sans-serif';
  ctx.fillText(
    'Optimal observed angle reflects the highest measured power during this experiment run. Processed locally in browser.',
    64,
    height - 32
  );

  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) {
          reject(new Error('Canvas failed to export PNG blob.'));
          return;
        }
        resolve(blob);
      },
      'image/png',
      1.0
    );
  });
}

export function downloadPngBlob(blob: Blob, filename: string = 'solar_panel_report.png'): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
