/**
 * Applies grayscale luminance, contrast stretching, threshold binarization,
 * and optional dark/light display inversion directly on RGBA pixel data.
 */
export function processGrayscaleContrastBinarize(
  data: Uint8ClampedArray,
  contrastThreshold: number = 128,
  invert: boolean = false
): Uint8ClampedArray {
  const threshold = Math.max(0, Math.min(255, contrastThreshold));
  const contrastFactor = 1.6;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    // Rec. 709 luminance
    let gray = 0.2126 * r + 0.7152 * g + 0.0722 * b;

    if (invert) {
      gray = 255 - gray;
    }

    // Contrast adjustment centered around 128
    const contrasted = (gray - 128) * contrastFactor + 128;
    const clamped = Math.max(0, Math.min(255, contrasted));

    // Threshold binarization (black text on white background works best for Tesseract)
    const binary = clamped >= threshold ? 255 : 0;

    data[i] = binary;
    data[i + 1] = binary;
    data[i + 2] = binary;
    data[i + 3] = 255;
  }

  return data;
}

/**
 * Extracts a normalized crop from a video or canvas source, upscales small crops
 * for cleaner Tesseract recognition, and applies grayscale + contrast + binarization.
 */
export function extractAndPreprocessCrop(
  source: HTMLVideoElement | HTMLCanvasElement,
  cropX: number,
  cropY: number,
  cropWidth: number,
  cropHeight: number,
  targetCanvas: HTMLCanvasElement,
  contrastThreshold: number,
  invert: boolean
): HTMLCanvasElement {
  // Upscale small OCR crops so digits have >= 48px height for reliable Tesseract recognition
  const scale = cropHeight < 64 ? Math.min(3, Math.ceil(64 / Math.max(1, cropHeight))) : 1;
  const padding = 12;
  const outW = cropWidth * scale + padding * 2;
  const outH = cropHeight * scale + padding * 2;

  if (targetCanvas.width !== outW) targetCanvas.width = outW;
  if (targetCanvas.height !== outH) targetCanvas.height = outH;

  const ctx = targetCanvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) {
    return targetCanvas;
  }

  ctx.fillStyle = invert ? '#000000' : '#FFFFFF';
  ctx.fillRect(0, 0, outW, outH);

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(
    source,
    cropX,
    cropY,
    cropWidth,
    cropHeight,
    padding,
    padding,
    cropWidth * scale,
    cropHeight * scale
  );

  const imageData = ctx.getImageData(0, 0, outW, outH);
  processGrayscaleContrastBinarize(imageData.data, contrastThreshold, invert);
  ctx.putImageData(imageData, 0, 0);

  return targetCanvas;
}
