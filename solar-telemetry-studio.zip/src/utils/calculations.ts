import { NormalizedRegion } from '../types/calibration';
import { AngleIntervalBin } from '../types/experiment';
import { SessionStatistics, TelemetrySample } from '../types/telemetry';

/**
 * Calculates electrical power in Watts: P = V * I.
 */
export function calculatePower(voltageV: number, currentA: number): number {
  if (!Number.isFinite(voltageV) || !Number.isFinite(currentA)) {
    return 0;
  }
  return Math.max(0, voltageV * currentA);
}

/**
 * Computes summary statistics and peak observed operating point for a set of samples.
 */
export function computeSessionStatistics(
  samples: TelemetrySample[]
): SessionStatistics {
  if (samples.length === 0) {
    return {
      sampleCount: 0,
      maxPowerW: 0,
      minPowerW: 0,
      averagePowerW: 0,
      powerVariationW: 0,
      averageVoltageV: 0,
      averageCurrentA: 0,
      peakObservedAngleDeg: null,
      peakSample: null,
      durationSeconds: 0,
    };
  }

  let maxPowerW = -Infinity;
  let minPowerW = Infinity;
  let sumPowerW = 0;
  let sumVoltageV = 0;
  let sumCurrentA = 0;
  let peakSample: TelemetrySample | null = null;
  let maxElapsed = 0;

  for (const sample of samples) {
    if (sample.powerW > maxPowerW) {
      maxPowerW = sample.powerW;
      peakSample = sample;
    }
    if (sample.powerW < minPowerW) {
      minPowerW = sample.powerW;
    }
    sumPowerW += sample.powerW;
    sumVoltageV += sample.voltageV;
    sumCurrentA += sample.currentA;
    if (sample.elapsedSeconds > maxElapsed) {
      maxElapsed = sample.elapsedSeconds;
    }
  }

  const count = samples.length;
  return {
    sampleCount: count,
    maxPowerW,
    minPowerW,
    averagePowerW: sumPowerW / count,
    powerVariationW: maxPowerW - minPowerW,
    averageVoltageV: sumVoltageV / count,
    averageCurrentA: sumCurrentA / count,
    peakObservedAngleDeg: peakSample ? peakSample.angleDeg : null,
    peakSample,
    durationSeconds: maxElapsed,
  };
}

/**
 * Groups telemetry samples into configurable angle intervals (e.g., 0-10, 10-20...)
 * and distinguishes measured bin averages from linearly interpolated estimates.
 */
export function computeAngleIntervalAnalysis(
  samples: TelemetrySample[],
  intervalDeg: number = 10,
  minSamplesPerBin: number = 1
): AngleIntervalBin[] {
  const safeInterval = Math.max(2, Math.min(45, Math.round(intervalDeg)));
  const maxAngleBound = 90;
  const bins: AngleIntervalBin[] = [];

  for (let start = 0; start < maxAngleBound; start += safeInterval) {
    const end = Math.min(maxAngleBound, start + safeInterval);
    const matching = samples.filter((s) => {
      if (end === maxAngleBound) {
        return s.angleDeg >= start && s.angleDeg <= end;
      }
      return s.angleDeg >= start && s.angleDeg < end;
    });

    const hasSufficient = matching.length >= minSamplesPerBin;
    let measuredAvg: number | null = null;
    let measuredMax: number | null = null;

    if (hasSufficient) {
      let sum = 0;
      let maxVal = -Infinity;
      for (const m of matching) {
        sum += m.powerW;
        if (m.powerW > maxVal) maxVal = m.powerW;
      }
      measuredAvg = sum / matching.length;
      measuredMax = maxVal;
    }

    bins.push({
      label: `${start}–${end}°`,
      minAngle: start,
      maxAngle: end,
      midpointAngle: (start + end) / 2,
      sampleCount: matching.length,
      measuredAveragePowerW: measuredAvg,
      measuredMaxPowerW: measuredMax,
      interpolatedPowerW: null,
      isInterpolated: false,
    });
  }

  // Linearly interpolate missing intermediate bins strictly between measured bins
  const measuredIndices: number[] = [];
  bins.forEach((b, idx) => {
    if (b.measuredAveragePowerW !== null) {
      measuredIndices.push(idx);
    }
  });

  if (measuredIndices.length >= 2) {
    for (let i = 0; i < measuredIndices.length - 1; i++) {
      const leftIdx = measuredIndices[i];
      const rightIdx = measuredIndices[i + 1];
      const leftVal = bins[leftIdx].measuredAveragePowerW!;
      const rightVal = bins[rightIdx].measuredAveragePowerW!;
      const span = rightIdx - leftIdx;
      for (let k = leftIdx + 1; k < rightIdx; k++) {
        const t = (k - leftIdx) / span;
        bins[k].interpolatedPowerW = leftVal + t * (rightVal - leftVal);
        bins[k].isInterpolated = true;
      }
    }
  }

  return bins;
}

export interface PixelRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

/**
 * Validates that a drawn CSS pixel rectangle meets the minimum 10x10 CSS pixel threshold.
 */
export function validateMinRegionSize(
  widthCss: number,
  heightCss: number,
  minPx: number = 10
): boolean {
  return widthCss >= minPx && heightCss >= minPx;
}

/**
 * Converts a rectangle drawn in displayed container CSS coordinates into
 * normalized [0..1] coordinates relative to the rendered video viewport.
 */
export function normalizeRegion(
  rect: PixelRect,
  viewportWidth: number,
  viewportHeight: number
): NormalizedRegion {
  if (viewportWidth <= 0 || viewportHeight <= 0) {
    return { x: 0, y: 0, width: 0, height: 0 };
  }

  const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
  const x = clamp01(rect.x / viewportWidth);
  const y = clamp01(rect.y / viewportHeight);
  const maxW = 1 - x;
  const maxH = 1 - y;
  const width = Math.max(0, Math.min(maxW, rect.width / viewportWidth));
  const height = Math.max(0, Math.min(maxH, rect.height / viewportHeight));

  return { x, y, width, height };
}

/**
 * Converts normalized [0..1] coordinates back into exact pixel coordinates
 * on the source video frame dimensions.
 */
export function denormalizeRegion(
  region: NormalizedRegion,
  videoWidth: number,
  videoHeight: number
): PixelRect {
  const sx = Math.max(0, Math.floor(region.x * videoWidth));
  const sy = Math.max(0, Math.floor(region.y * videoHeight));
  const sw = Math.max(1, Math.min(videoWidth - sx, Math.round(region.width * videoWidth)));
  const sh = Math.max(1, Math.min(videoHeight - sy, Math.round(region.height * videoHeight)));

  return { x: sx, y: sy, width: sw, height: sh };
}

/**
 * Formats seconds into HH:MM:SS or MM:SS timer string.
 */
export function formatDuration(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = safe % 60;
  const pad = (n: number) => n.toString().padStart(2, '0');
  if (hrs > 0) {
    return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
  }
  return `${pad(mins)}:${pad(secs)}`;
}
