import { useEffect, useRef } from 'react';
import { MetricSampleInput } from './useTelemetry';

export interface UseDemoSimulatorOptions {
  isActive: boolean;
  isPaused: boolean;
  samplingIntervalMs: number;
  peakAngleDeg: number;
  onReadings: (readings: MetricSampleInput) => void;
}

/**
 * Generates realistic solar panel tilt angle, voltage, and current readings
 * around a configurable optimal peak angle with measurement noise.
 */
export function generateSimulatedTelemetryStep(
  stepIndex: number,
  peakAngleDeg: number
): { angleDeg: number; voltageV: number; currentA: number } {
  // Smooth continuous sweep between 8 deg and 68 deg (period ~60 steps)
  const phase = (stepIndex % 60) / 60;
  const triangle = phase <= 0.5 ? phase * 2 : (1 - phase) * 2;
  const baseAngle = 8 + triangle * 60;
  const angleNoise = Math.sin(stepIndex * 1.7) * 0.35;
  const angleDeg = Number(Math.max(0, Math.min(85, baseAngle + angleNoise)).toFixed(1));

  // Solar cosine incidence efficiency relative to peakAngleDeg
  const deltaRad = ((angleDeg - peakAngleDeg) * Math.PI) / 180;
  const incidenceFactor = Math.max(0.28, Math.cos(deltaRad * 1.35));

  // Open-circuit voltage shifts subtly with irradiance + thermal drift
  const voltageV = Number(
    (
      17.4 +
      2.2 * Math.pow(incidenceFactor, 0.45) +
      Math.sin(stepIndex * 0.9) * 0.14
    ).toFixed(2)
  );

  // Current scales strongly with cosine incidence angle + slight cloud ripple
  const cloudRipple = Math.sin(stepIndex * 0.31) * 0.06 + Math.cos(stepIndex * 1.3) * 0.04;
  const currentA = Number(
    Math.max(0.25, 0.55 + 2.85 * Math.pow(incidenceFactor, 1.8) + cloudRipple).toFixed(2)
  );

  return { angleDeg, voltageV, currentA };
}

export function useDemoSimulator({
  isActive,
  isPaused,
  samplingIntervalMs,
  peakAngleDeg,
  onReadings,
}: UseDemoSimulatorOptions) {
  const stepRef = useRef(0);
  const timerRef = useRef<number | null>(null);
  const onReadingsRef = useRef(onReadings);
  onReadingsRef.current = onReadings;

  useEffect(() => {
    if (!isActive || isPaused) {
      if (timerRef.current !== null) {
        window.clearInterval(timerRef.current);
        timerRef.current = null;
      }
      return;
    }

    const emitStep = () => {
      const { angleDeg, voltageV, currentA } = generateSimulatedTelemetryStep(
        stepRef.current,
        peakAngleDeg
      );
      stepRef.current += 1;

      onReadingsRef.current({
        angle: { value: angleDeg, confidence: 99, rawText: String(angleDeg) },
        voltage: { value: voltageV, confidence: 99, rawText: String(voltageV) },
        current: { value: currentA, confidence: 99, rawText: String(currentA) },
      });
    };

    emitStep();
    const safeInterval = Math.max(250, samplingIntervalMs);
    timerRef.current = window.setInterval(emitStep, safeInterval);

    return () => {
      if (timerRef.current !== null) {
        window.clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [isActive, isPaused, samplingIntervalMs, peakAngleDeg]);

  const resetSimulator = () => {
    stepRef.current = 0;
  };

  return { resetSimulator };
}
