import { useCallback, useRef, useState } from 'react';
import {
  CALIBRATION_STEPS,
  CalibrationRegions,
  NormalizedRegion,
  PartialCalibrationRegions,
} from '../types/calibration';
import { normalizeRegion, PixelRect, validateMinRegionSize } from '../utils/calculations';

export interface UseRegionSelectionOptions {
  onComplete: (regions: CalibrationRegions) => void;
}

export function useRegionSelection({ onComplete }: UseRegionSelectionOptions) {
  const [regions, setRegions] = useState<PartialCalibrationRegions>({});
  const [activeDraftRect, setActiveDraftRect] = useState<PixelRect | null>(null);
  const [validationMessage, setValidationMessage] = useState<string | null>(null);

  const dragStartRef = useRef<{ x: number; y: number } | null>(null);
  const pointerIdRef = useRef<number | null>(null);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  const currentStepIndex: 0 | 1 | 2 | 3 = !regions.angle
    ? 0
    : !regions.voltage
    ? 1
    : !regions.current
    ? 2
    : 3;

  const activeStepConfig =
    currentStepIndex < 3 ? CALIBRATION_STEPS[currentStepIndex] : null;

  const getLocalCoords = (
    clientX: number,
    clientY: number,
    containerEl: HTMLElement
  ): { x: number; y: number; width: number; height: number } => {
    const bounds = containerEl.getBoundingClientRect();
    const x = Math.max(0, Math.min(bounds.width, clientX - bounds.left));
    const y = Math.max(0, Math.min(bounds.height, clientY - bounds.top));
    return { x, y, width: bounds.width, height: bounds.height };
  };

  const handlePointerDown = useCallback(
    (e: React.PointerEvent<HTMLElement>) => {
      if (currentStepIndex >= 3) return;
      if (e.button !== 0 && e.pointerType === 'mouse') return;

      const target = e.currentTarget;
      try {
        target.setPointerCapture(e.pointerId);
      } catch {
        // Ignore if pointer capture unsupported
      }

      pointerIdRef.current = e.pointerId;
      const { x, y } = getLocalCoords(e.clientX, e.clientY, target);
      dragStartRef.current = { x, y };
      setActiveDraftRect({ x, y, width: 0, height: 0 });
      setValidationMessage(null);
    },
    [currentStepIndex]
  );

  const handlePointerMove = useCallback(
    (e: React.PointerEvent<HTMLElement>) => {
      if (!dragStartRef.current || pointerIdRef.current !== e.pointerId) return;
      const { x, y } = getLocalCoords(e.clientX, e.clientY, e.currentTarget);
      const start = dragStartRef.current;

      setActiveDraftRect({
        x: Math.min(start.x, x),
        y: Math.min(start.y, y),
        width: Math.abs(x - start.x),
        height: Math.abs(y - start.y),
      });
    },
    []
  );

  const handlePointerUp = useCallback(
    (e: React.PointerEvent<HTMLElement>) => {
      if (!dragStartRef.current || pointerIdRef.current !== e.pointerId) return;

      const target = e.currentTarget;
      try {
        if (target.hasPointerCapture(e.pointerId)) {
          target.releasePointerCapture(e.pointerId);
        }
      } catch {
        // Ignore
      }

      const { x, y, width: containerW, height: containerH } = getLocalCoords(
        e.clientX,
        e.clientY,
        target
      );
      const start = dragStartRef.current;
      dragStartRef.current = null;
      pointerIdRef.current = null;
      setActiveDraftRect(null);

      const finalRect: PixelRect = {
        x: Math.min(start.x, x),
        y: Math.min(start.y, y),
        width: Math.abs(x - start.x),
        height: Math.abs(y - start.y),
      };

      if (!validateMinRegionSize(finalRect.width, finalRect.height, 10)) {
        setValidationMessage(
          'Selection must be at least 10 × 10 pixels. Click and drag a larger box around the reading.'
        );
        return;
      }

      const normalized: NormalizedRegion = normalizeRegion(
        finalRect,
        containerW,
        containerH
      );

      if (!activeStepConfig) return;

      const nextRegions: PartialCalibrationRegions = {
        ...regions,
        [activeStepConfig.metric]: normalized,
      };
      setRegions(nextRegions);
      setValidationMessage(null);

      if (nextRegions.angle && nextRegions.voltage && nextRegions.current) {
        onCompleteRef.current({
          angle: nextRegions.angle,
          voltage: nextRegions.voltage,
          current: nextRegions.current,
        });
      }
    },
    [activeStepConfig, regions]
  );

  const undoLast = useCallback(() => {
    setValidationMessage(null);
    setRegions((prev) => {
      if (prev.current) {
        const { current: _removed, ...rest } = prev;
        return rest;
      }
      if (prev.voltage) {
        const { voltage: _removed, ...rest } = prev;
        return rest;
      }
      if (prev.angle) {
        return {};
      }
      return prev;
    });
  }, []);

  const resetAll = useCallback(() => {
    dragStartRef.current = null;
    pointerIdRef.current = null;
    setActiveDraftRect(null);
    setValidationMessage(null);
    setRegions({});
  }, []);

  const setPresetRegions = useCallback((preset: CalibrationRegions) => {
    setRegions(preset);
    setValidationMessage(null);
  }, []);

  return {
    regions,
    currentStepIndex,
    activeStepConfig,
    activeDraftRect,
    validationMessage,
    handlePointerDown,
    handlePointerMove,
    handlePointerUp,
    undoLast,
    resetAll,
    setPresetRegions,
  };
}
