import { useCallback, useEffect, useRef, useState } from 'react';

export interface VideoDimensions {
  width: number;
  height: number;
}

export interface UseScreenCaptureOptions {
  onStreamEnded?: () => void;
}

export function useScreenCapture({ onStreamEnded }: UseScreenCaptureOptions = {}) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isRequesting, setIsRequesting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [videoDimensions, setVideoDimensions] = useState<VideoDimensions | null>(null);
  const [trackLabel, setTrackLabel] = useState<string>('');

  const streamRef = useRef<MediaStream | null>(null);
  const onStreamEndedRef = useRef(onStreamEnded);
  onStreamEndedRef.current = onStreamEnded;

  const isSupported =
    typeof navigator !== 'undefined' &&
    Boolean(navigator.mediaDevices && typeof navigator.mediaDevices.getDisplayMedia === 'function');

  const stopCapture = useCallback(() => {
    const activeStream = streamRef.current;
    if (activeStream) {
      activeStream.getTracks().forEach((track) => {
        track.onended = null;
        try {
          track.stop();
        } catch {
          // Ignore track stop errors
        }
      });
    }
    streamRef.current = null;
    setStream(null);
    setVideoDimensions(null);
    setTrackLabel('');
  }, []);

  const startCapture = useCallback(async (): Promise<MediaStream | null> => {
    setError(null);

    if (!isSupported) {
      setError(
        'Screen capture (navigator.mediaDevices.getDisplayMedia) is not supported in this browser or context. Use a modern desktop Chromium, Firefox, or Edge browser over HTTPS/localhost, or use Demo Simulator.'
      );
      return null;
    }

    // Stop any previous stream before requesting a new one
    stopCapture();
    setIsRequesting(true);

    try {
      const mediaStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          frameRate: { ideal: 30, max: 60 },
        },
        audio: false,
      });

      const videoTrack = mediaStream.getVideoTracks()[0];
      if (!videoTrack) {
        mediaStream.getTracks().forEach((t) => t.stop());
        setError('No video track was provided by the selected screen source.');
        setIsRequesting(false);
        return null;
      }

      const settings = videoTrack.getSettings();
      if (settings.width && settings.height) {
        setVideoDimensions({ width: settings.width, height: settings.height });
      }
      setTrackLabel(videoTrack.label || 'Mirrored Screen Source');

      videoTrack.onended = () => {
        streamRef.current = null;
        setStream(null);
        setVideoDimensions(null);
        setTrackLabel('');
        onStreamEndedRef.current?.();
      };

      streamRef.current = mediaStream;
      setStream(mediaStream);
      setIsRequesting(false);
      return mediaStream;
    } catch (err) {
      setIsRequesting(false);
      if (err instanceof DOMException) {
        if (err.name === 'NotAllowedError') {
          setError(
            'Screen-sharing permission was denied or cancelled. Grant display capture access to mirror your Android telemetry window.'
          );
        } else if (err.name === 'NotFoundError' || err.name === 'OverconstrainedError') {
          setError('No compatible screen or window source was available for capture.');
        } else if (err.name === 'NotSupportedError' || err.name === 'SecurityError') {
          setError(
            'Screen capture is blocked by browser permissions policy or insecure context.'
          );
        } else {
          setError(`Screen capture failed (${err.name}): ${err.message}`);
        }
      } else {
        setError('An unexpected error occurred while starting screen capture.');
      }
      return null;
    }
  }, [isSupported, stopCapture]);

  const updateVideoMetadataDimensions = useCallback((width: number, height: number) => {
    if (width > 0 && height > 0) {
      setVideoDimensions({ width, height });
    }
  }, []);

  useEffect(() => {
    return () => {
      stopCapture();
    };
  }, [stopCapture]);

  return {
    stream,
    isSupported,
    isRequesting,
    error,
    videoDimensions,
    trackLabel,
    startCapture,
    stopCapture,
    clearError: () => setError(null),
    updateVideoMetadataDimensions,
  };
}
