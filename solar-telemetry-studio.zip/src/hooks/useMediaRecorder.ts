import { useCallback, useEffect, useRef, useState } from 'react';
import { RecordingMetadata } from '../types/experiment';
import { RecordingStatus } from '../types/telemetry';
import {
  createRecordingBlob,
  getRecordingFilename,
  getSupportedRecordingMimeType,
  isMediaRecorderSupported,
} from '../services/recordingService';

export function useMediaRecorder() {
  const [status, setStatus] = useState<RecordingStatus>('idle');
  const [durationSeconds, setDurationSeconds] = useState(0);
  const [mimeType, setMimeType] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);

  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const timerRef = useRef<number | null>(null);
  const startTimeRef = useRef<number | null>(null);
  const activeMimeRef = useRef<string | null>(null);

  const clearTimer = useCallback(() => {
    if (timerRef.current !== null) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const startRecording = useCallback(
    (stream: MediaStream | null): boolean => {
      setError(null);
      setRecordedBlob(null);
      chunksRef.current = [];
      setDurationSeconds(0);

      if (!stream) {
        setStatus('error');
        setError('Cannot start screen recording without an active display stream.');
        return false;
      }

      if (!isMediaRecorderSupported()) {
        setStatus('unsupported');
        setError('MediaRecorder API is not supported in this browser.');
        return false;
      }

      const supportedMime = getSupportedRecordingMimeType();
      if (supportedMime === null) {
        setStatus('unsupported');
        setError('No supported video recording MIME type is available.');
        return false;
      }

      try {
        const options: MediaRecorderOptions =
          supportedMime.length > 0 ? { mimeType: supportedMime } : {};
        const recorder = new MediaRecorder(stream, options);
        const resolvedMime = recorder.mimeType || supportedMime || 'video/webm';
        activeMimeRef.current = resolvedMime;
        setMimeType(resolvedMime);

        recorder.ondataavailable = (event: BlobEvent) => {
          if (event.data && event.data.size > 0) {
            chunksRef.current.push(event.data);
          }
        };

        recorder.onstart = () => {
          startTimeRef.current = Date.now();
          setStatus('recording');
          clearTimer();
          timerRef.current = window.setInterval(() => {
            if (startTimeRef.current !== null) {
              setDurationSeconds(
                Math.floor((Date.now() - startTimeRef.current) / 1000)
              );
            }
          }, 500);
        };

        recorder.onerror = () => {
          clearTimer();
          setStatus('error');
          setError('Screen recording encountered an encoder error.');
        };

        recorder.onstop = () => {
          clearTimer();
          const finalBlob = createRecordingBlob(
            chunksRef.current,
            activeMimeRef.current
          );
          setRecordedBlob(finalBlob);
          setStatus((prev) => (prev === 'error' ? 'error' : 'stopped'));
        };

        recorder.start(1000);
        recorderRef.current = recorder;
        return true;
      } catch (err) {
        clearTimer();
        setStatus('error');
        setError(
          err instanceof Error
            ? `Failed to start MediaRecorder: ${err.message}`
            : 'Failed to start screen recording.'
        );
        return false;
      }
    },
    [clearTimer]
  );

  const stopRecording = useCallback((): Promise<Blob | null> => {
    clearTimer();
    const recorder = recorderRef.current;

    if (!recorder || recorder.state === 'inactive') {
      const existingBlob = createRecordingBlob(
        chunksRef.current,
        activeMimeRef.current
      );
      if (existingBlob) {
        setRecordedBlob(existingBlob);
      }
      if (status === 'recording') {
        setStatus('stopped');
      }
      return Promise.resolve(existingBlob);
    }

    return new Promise<Blob | null>((resolve) => {
      const prevOnStop = recorder.onstop;
      recorder.onstop = (ev) => {
        if (typeof prevOnStop === 'function') {
          prevOnStop.call(recorder, ev);
        }
        const blob = createRecordingBlob(
          chunksRef.current,
          activeMimeRef.current
        );
        setRecordedBlob(blob);
        resolve(blob);
      };

      try {
        recorder.stop();
      } catch {
        const blob = createRecordingBlob(
          chunksRef.current,
          activeMimeRef.current
        );
        setRecordedBlob(blob);
        setStatus('stopped');
        resolve(blob);
      }
    });
  }, [clearTimer, status]);

  const resetRecording = useCallback(() => {
    clearTimer();
    if (recorderRef.current && recorderRef.current.state !== 'inactive') {
      try {
        recorderRef.current.stop();
      } catch {
        // Ignore
      }
    }
    recorderRef.current = null;
    chunksRef.current = [];
    startTimeRef.current = null;
    activeMimeRef.current = null;
    setRecordedBlob(null);
    setMimeType(null);
    setDurationSeconds(0);
    setError(null);
    setStatus('idle');
  }, [clearTimer]);

  const getRecordingMetadata = useCallback((): RecordingMetadata => {
    return {
      hasRecording: recordedBlob !== null && recordedBlob.size > 0,
      mimeType,
      sizeBytes: recordedBlob?.size ?? 0,
      durationSeconds,
      error,
    };
  }, [durationSeconds, error, mimeType, recordedBlob]);

  useEffect(() => {
    return () => {
      clearTimer();
      if (recorderRef.current && recorderRef.current.state !== 'inactive') {
        try {
          recorderRef.current.stop();
        } catch {
          // Ignore
        }
      }
    };
  }, [clearTimer]);

  return {
    status,
    durationSeconds,
    mimeType,
    filename: getRecordingFilename(mimeType),
    error,
    recordedBlob,
    startRecording,
    stopRecording,
    resetRecording,
    getRecordingMetadata,
  };
}
