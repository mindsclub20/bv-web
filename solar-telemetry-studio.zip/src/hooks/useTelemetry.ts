import { useCallback, useMemo, useRef, useState } from 'react';
import {
  MetricReadState,
  SessionStatistics,
  TelemetrySample,
} from '../types/telemetry';
import { calculatePower, computeSessionStatistics } from '../utils/calculations';

const INITIAL_METRIC_STATE: MetricReadState = {
  value: null,
  isValid: false,
  isFresh: false,
  lastUpdatedAt: null,
  confidence: 0,
  rawText: '',
};

export interface MetricSampleInput {
  angle: { value: number | null; confidence: number; rawText: string };
  voltage: { value: number | null; confidence: number; rawText: string };
  current: { value: number | null; confidence: number; rawText: string };
}

export function useTelemetry() {
  const [samples, setSamples] = useState<TelemetrySample[]>([]);
  const [angleState, setAngleState] = useState<MetricReadState>(INITIAL_METRIC_STATE);
  const [voltageState, setVoltageState] = useState<MetricReadState>(INITIAL_METRIC_STATE);
  const [currentState, setCurrentState] = useState<MetricReadState>(INITIAL_METRIC_STATE);
  const [sessionStartMs, setSessionStartMs] = useState<number | null>(null);

  const angleRef = useRef<MetricReadState>(INITIAL_METRIC_STATE);
  const voltageRef = useRef<MetricReadState>(INITIAL_METRIC_STATE);
  const currentRef = useRef<MetricReadState>(INITIAL_METRIC_STATE);
  const sessionStartRef = useRef<number | null>(null);
  const sampleCounterRef = useRef(0);

  const startSessionClock = useCallback(() => {
    const now = Date.now();
    sessionStartRef.current = now;
    setSessionStartMs(now);
  }, []);

  const resetTelemetry = useCallback(() => {
    sampleCounterRef.current = 0;
    sessionStartRef.current = null;
    angleRef.current = INITIAL_METRIC_STATE;
    voltageRef.current = INITIAL_METRIC_STATE;
    currentRef.current = INITIAL_METRIC_STATE;
    setSamples([]);
    setAngleState(INITIAL_METRIC_STATE);
    setVoltageState(INITIAL_METRIC_STATE);
    setCurrentState(INITIAL_METRIC_STATE);
    setSessionStartMs(null);
  }, []);

  /**
   * Fault-tolerant telemetry update:
   * - Never replaces a failed OCR read with zero; retains previous valid value.
   * - Maintains independent validity & freshness state per metric.
   * - Appends a new TelemetrySample when all three metrics have valid numbers.
   */
  const recordReadings = useCallback((input: MetricSampleInput): TelemetrySample | null => {
    const now = Date.now();
    if (sessionStartRef.current === null) {
      sessionStartRef.current = now;
      setSessionStartMs(now);
    }

    const updateMetric = (
      prev: MetricReadState,
      incoming: { value: number | null; confidence: number; rawText: string }
    ): MetricReadState => {
      if (incoming.value !== null && Number.isFinite(incoming.value)) {
        return {
          value: incoming.value,
          isValid: true,
          isFresh: true,
          lastUpdatedAt: now,
          confidence: incoming.confidence,
          rawText: incoming.rawText,
        };
      }
      return {
        ...prev,
        isFresh: false,
        rawText: incoming.rawText,
      };
    };

    const nextAngle = updateMetric(angleRef.current, input.angle);
    const nextVoltage = updateMetric(voltageRef.current, input.voltage);
    const nextCurrent = updateMetric(currentRef.current, input.current);

    angleRef.current = nextAngle;
    voltageRef.current = nextVoltage;
    currentRef.current = nextCurrent;

    setAngleState(nextAngle);
    setVoltageState(nextVoltage);
    setCurrentState(nextCurrent);

    if (
      nextAngle.value !== null &&
      nextVoltage.value !== null &&
      nextCurrent.value !== null
    ) {
      const powerW = calculatePower(nextVoltage.value, nextCurrent.value);
      const elapsedSeconds = Number(
        ((now - (sessionStartRef.current ?? now)) / 1000).toFixed(2)
      );
      sampleCounterRef.current += 1;
      const newSample: TelemetrySample = {
        id: `sample-${now}-${sampleCounterRef.current}`,
        timestampMs: now,
        elapsedSeconds,
        angleDeg: nextAngle.value,
        voltageV: nextVoltage.value,
        currentA: nextCurrent.value,
        powerW,
      };
      setSamples((prev) => [...prev, newSample]);
      return newSample;
    }

    return null;
  }, []);

  const statistics: SessionStatistics = useMemo(
    () => computeSessionStatistics(samples),
    [samples]
  );

  const currentPowerW = useMemo(() => {
    if (voltageState.value === null || currentState.value === null) {
      return null;
    }
    return calculatePower(voltageState.value, currentState.value);
  }, [voltageState.value, currentState.value]);

  return {
    samples,
    angleState,
    voltageState,
    currentState,
    currentPowerW,
    statistics,
    sessionStartMs,
    startSessionClock,
    recordReadings,
    resetTelemetry,
  };
}
