import { useCallback, useState } from 'react';
import {
  clearStoredExperiments,
  loadExperiments,
  loadSettings,
  saveExperiments,
  saveSettings,
} from '../services/experimentService';
import { ExperimentSession } from '../types/experiment';
import { AppSettings } from '../types/telemetry';

export function useExperimentStorage() {
  const initialLoad = loadExperiments();
  const [experiments, setExperiments] = useState<ExperimentSession[]>(initialLoad.data);
  const [storageError, setStorageError] = useState<string | null>(initialLoad.error);
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());

  const addOrUpdateExperiment = useCallback((session: ExperimentSession) => {
    setExperiments((prev) => {
      const existingIndex = prev.findIndex((item) => item.id === session.id);
      const next =
        existingIndex >= 0
          ? prev.map((item, idx) => (idx === existingIndex ? session : item))
          : [session, ...prev];
      const { error } = saveExperiments(next);
      setStorageError(error);
      return next;
    });
  }, []);

  const deleteExperiment = useCallback((id: string) => {
    setExperiments((prev) => {
      const next = prev.filter((item) => item.id !== id);
      const { error } = saveExperiments(next);
      setStorageError(error);
      return next;
    });
  }, []);

  const clearAllExperiments = useCallback(() => {
    const { error } = clearStoredExperiments();
    setStorageError(error);
    if (!error) {
      setExperiments([]);
    }
  }, []);

  const updateSettings = useCallback((patch: Partial<AppSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      const { error } = saveSettings(next);
      if (error) setStorageError(error);
      return next;
    });
  }, []);

  return {
    experiments,
    storageError,
    settings,
    addOrUpdateExperiment,
    deleteExperiment,
    clearAllExperiments,
    updateSettings,
    clearStorageError: () => setStorageError(null),
  };
}
