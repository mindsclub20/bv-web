import { useCallback, useEffect, useRef, useState } from 'react';
import { ocrService } from '../services/ocrService';
import { CalibrationRegions } from '../types/calibration';
import { OCRDiagnostics } from '../types/telemetry';
import { denormalizeRegion } from '../utils/calculations';
import { extractAndPreprocessCrop } from '../utils/imageProcessing';
import { parseNumericReading } from '../utils/numericParser';
import { MetricSampleInput } from './useTelemetry';

const INITIAL_DIAGNOSTICS: OCRDiagnostics = {
  engineStatus: 'idle',
  initProgress: 0,
  initMessage: 'OCR worker idle',
  lastLatencyMs: null,
  lastSuccessAt: null,
  failedSampleCount: 0,
  totalSampleCount: 0,
  averageConfidence: 0,
  lastError: null,
};

export interface UseSolarOCROptions {
  videoRef: React.RefObject<HTMLVideoElement | null>;
  regions: CalibrationRegions | null;
  isActive: boolean;
  isPaused: boolean;
  samplingIntervalMs: number;
  contrastThreshold: number;
  invertDisplay: boolean;
  onReadings: (readings: MetricSampleInput) => void;
}

export function useSolarOCR({
  videoRef,
  regions,
  isActive,
  isPaused,
  samplingIntervalMs,
  contrastThreshold,
  invertDisplay,
  onReadings,
}: UseSolarOCROptions) {
  const [diagnostics, setDiagnostics] = useState<OCRDiagnostics>(INITIAL_DIAGNOSTICS);

  const isProcessingRef = useRef(false);
  const timerRef = useRef<number | null>(null);
  const onReadingsRef = useRef(onReadings);
  onReadingsRef.current = onReadings;

  const angleCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const voltageCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const currentCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const getCropCanvas = (ref: React.MutableRefObject<HTMLCanvasElement | null>) => {
    if (!ref.current) {
      ref.current = document.createElement('canvas');
    }
    return ref.current;
  };

  const resetDiagnostics = useCallback(() => {
    setDiagnostics(INITIAL_DIAGNOSTICS);
  }, []);

  const shutdownOCR = useCallback(async () => {
    if (timerRef.current !== null) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    isProcessingRef.current = false;
    await ocrService.terminate();
    setDiagnostics(INITIAL_DIAGNOSTICS);
  }, []);

  useEffect(() => {
    if (!isActive || !regions) {
      if (timerRef.current !== null) {
        window.clearInterval(timerRef.current);
        timerRef.current = null;
      }
      if (!isActive) {
        isProcessingRef.current = false;
      }
      return;
    }

    if (isPaused) {
      if (timerRef.current !== null) {
        window.clearInterval(timerRef.current);
        timerRef.current = null;
      }
      setDiagnostics((prev) => ({
        ...prev,
        engineStatus: 'paused',
      }));
      return;
    }

    let cancelled = false;

    const initAndRun = async () => {
      try {
        if (!ocrService.isReady()) {
          setDiagnostics((prev) => ({
            ...prev,
            engineStatus: 'initializing',
            initProgress: 0.05,
            initMessage: 'Initializing Tesseract OCR worker...',
            lastError: null,
          }));
          await ocrService.initialize((progress, status) => {
            if (!cancelled) {
              setDiagnostics((prev) => ({
                ...prev,
                engineStatus: progress >= 1 ? 'ready' : 'initializing',
                initProgress: progress,
                initMessage: status,
              }));
            }
          });
        }

        if (cancelled) return;

        setDiagnostics((prev) => ({
          ...prev,
          engineStatus: 'ready',
          initProgress: 1,
          initMessage: 'OCR worker active',
          lastError: null,
        }));

        const runCycle = async () => {
          if (cancelled || isProcessingRef.current) {
            return;
          }
          const videoEl = videoRef.current;
          if (
            !videoEl ||
            videoEl.readyState < 2 ||
            videoEl.videoWidth === 0 ||
            videoEl.videoHeight === 0
          ) {
            return;
          }

          isProcessingRef.current = true;
          const cycleStart = performance.now();
          setDiagnostics((prev) => ({ ...prev, engineStatus: 'processing' }));

          try {
            const vw = videoEl.videoWidth;
            const vh = videoEl.videoHeight;

            const angleRect = denormalizeRegion(regions.angle, vw, vh);
            const voltageRect = denormalizeRegion(regions.voltage, vw, vh);
            const currentRect = denormalizeRegion(regions.current, vw, vh);

            const angleCanvas = extractAndPreprocessCrop(
              videoEl,
              angleRect.x,
              angleRect.y,
              angleRect.width,
              angleRect.height,
              getCropCanvas(angleCanvasRef),
              contrastThreshold,
              invertDisplay
            );
            const voltageCanvas = extractAndPreprocessCrop(
              videoEl,
              voltageRect.x,
              voltageRect.y,
              voltageRect.width,
              voltageRect.height,
              getCropCanvas(voltageCanvasRef),
              contrastThreshold,
              invertDisplay
            );
            const currentCanvas = extractAndPreprocessCrop(
              videoEl,
              currentRect.x,
              currentRect.y,
              currentRect.width,
              currentRect.height,
              getCropCanvas(currentCanvasRef),
              contrastThreshold,
              invertDisplay
            );

            // Sequential recognition within the single Tesseract worker
            const angleRes = await ocrService.recognizeCanvas(angleCanvas);
            if (cancelled) return;
            const voltageRes = await ocrService.recognizeCanvas(voltageCanvas);
            if (cancelled) return;
            const currentRes = await ocrService.recognizeCanvas(currentCanvas);
            if (cancelled) return;

            const angleVal = parseNumericReading(angleRes.text, { min: -90, max: 180 });
            const voltageVal = parseNumericReading(voltageRes.text, { min: 0, max: 1000 });
            const currentVal = parseNumericReading(currentRes.text, { min: 0, max: 500 });

            onReadingsRef.current({
              angle: { value: angleVal, confidence: angleRes.confidence, rawText: angleRes.text },
              voltage: { value: voltageVal, confidence: voltageRes.confidence, rawText: voltageRes.text },
              current: { value: currentVal, confidence: currentRes.confidence, rawText: currentRes.text },
            });

            const latencyMs = Math.round(performance.now() - cycleStart);
            const avgConf = Math.round(
              (angleRes.confidence + voltageRes.confidence + currentRes.confidence) / 3
            );
            const allValid = angleVal !== null && voltageVal !== null && currentVal !== null;
            const anyFailed = angleVal === null || voltageVal === null || currentVal === null;

            setDiagnostics((prev) => ({
              ...prev,
              engineStatus: 'ready',
              lastLatencyMs: latencyMs,
              lastSuccessAt: allValid ? Date.now() : prev.lastSuccessAt,
              failedSampleCount: prev.failedSampleCount + (anyFailed ? 1 : 0),
              totalSampleCount: prev.totalSampleCount + 1,
              averageConfidence: avgConf,
              lastError: null,
            }));
          } catch (err) {
            if (!cancelled) {
              setDiagnostics((prev) => ({
                ...prev,
                engineStatus: 'error',
                failedSampleCount: prev.failedSampleCount + 1,
                totalSampleCount: prev.totalSampleCount + 1,
                lastError:
                  err instanceof Error ? err.message : 'OCR recognition cycle failed.',
              }));
            }
          } finally {
            isProcessingRef.current = false;
          }
        };

        void runCycle();
        const safeInterval = Math.max(250, samplingIntervalMs);
        timerRef.current = window.setInterval(() => {
          void runCycle();
        }, safeInterval);
      } catch (err) {
        if (!cancelled) {
          setDiagnostics((prev) => ({
            ...prev,
            engineStatus: 'error',
            lastError:
              err instanceof Error
                ? err.message
                : 'Failed to load OCR worker from CDN.',
          }));
        }
      }
    };

    void initAndRun();

    return () => {
      cancelled = true;
      if (timerRef.current !== null) {
        window.clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [
    isActive,
    isPaused,
    regions,
    samplingIntervalMs,
    contrastThreshold,
    invertDisplay,
    videoRef,
  ]);

  useEffect(() => {
    return () => {
      void ocrService.terminate();
    };
  }, []);

  return {
    diagnostics,
    resetDiagnostics,
    shutdownOCR,
  };
}
