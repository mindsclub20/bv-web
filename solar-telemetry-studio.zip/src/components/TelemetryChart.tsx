import React from 'react';
import {
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  Tooltip,
  XAxis,
  YAxis,
  ZAxis,
} from 'recharts';
import { TelemetrySample } from '../types/telemetry';

interface LineTelemetryChartProps {
  title: string;
  unit: string;
  color: string;
  data: TelemetrySample[];
  dataKey: 'angleDeg' | 'voltageV' | 'currentA';
  seriesName: string;
  precision: number;
}

export const LineTelemetryChart: React.FC<LineTelemetryChartProps> = ({
  title,
  unit,
  color,
  data,
  dataKey,
  seriesName,
  precision,
}) => {
  return (
    <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-5">
      <div className="mb-3 flex items-center justify-between gap-2">
        <h3 className="text-sm font-semibold text-slate-100">{title}</h3>
        <span className="font-mono text-xs text-slate-400">{unit}</span>
      </div>

      {data.length === 0 ? (
        <div className="flex h-[240px] items-center justify-center rounded-lg border border-dashed border-[#253247] bg-[#080D18]/60 text-xs text-slate-500">
          Waiting for telemetry samples...
        </div>
      ) : (
        <div className="h-[240px] w-full">
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={data} margin={{ top: 8, right: 16, left: 0, bottom: 16 }}>
              <CartesianGrid stroke="#1E293B" strokeDasharray="3 3" />
              <XAxis
                dataKey="elapsedSeconds"
                type="number"
                domain={['auto', 'auto']}
                tick={{ fill: '#64748B', fontSize: 11 }}
                stroke="#253247"
                tickFormatter={(v) => `${Number(v).toFixed(0)}s`}
                label={{
                  value: 'Elapsed Time (s)',
                  position: 'insideBottom',
                  offset: -10,
                  fill: '#94A3B8',
                  fontSize: 11,
                }}
              />
              <YAxis
                tick={{ fill: '#64748B', fontSize: 11 }}
                stroke="#253247"
                width={52}
                domain={['auto', 'auto']}
                tickFormatter={(v) =>
                  Number(v).toFixed(dataKey === 'angleDeg' ? 1 : 2)
                }
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#080D18',
                  borderColor: '#253247',
                  borderRadius: '8px',
                  fontSize: '12px',
                  color: '#F8FAFC',
                }}
                formatter={(val) => [`${Number(val ?? 0).toFixed(precision)} ${unit}`, seriesName]}
                labelFormatter={(label) => `t = ${Number(label).toFixed(2)}s`}
              />
              <Line
                type="monotone"
                dataKey={dataKey}
                name={seriesName}
                stroke={color}
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4, fill: color }}
                isAnimationActive={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
};

interface AnglePowerScatterChartProps {
  data: TelemetrySample[];
  peakSample: TelemetrySample | null;
  precision: number;
}

export const AnglePowerScatterChart: React.FC<AnglePowerScatterChartProps> = ({
  data,
  peakSample,
  precision,
}) => {
  const regularPoints = peakSample
    ? data.filter((d) => d.id !== peakSample.id)
    : data;
  const peakPoints = peakSample ? [peakSample] : [];

  return (
    <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-5">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h3 className="text-sm font-semibold text-slate-100">
          Tilt Angle vs Power
          {peakSample && (
            <span className="ml-2 font-mono text-xs font-semibold text-[#FACC15]">
              (Peak: {peakSample.powerW.toFixed(precision)} W @{' '}
              {peakSample.angleDeg.toFixed(1)}°)
            </span>
          )}
        </h3>
        <span className="font-mono text-xs text-slate-400">W vs °</span>
      </div>

      {data.length === 0 ? (
        <div className="flex h-[240px] items-center justify-center rounded-lg border border-dashed border-[#253247] bg-[#080D18]/60 text-xs text-slate-500">
          Waiting for angle & power observations...
        </div>
      ) : (
        <div className="h-[240px] w-full">
          <ResponsiveContainer width="100%" height={240}>
            <ScatterChart margin={{ top: 8, right: 16, left: 0, bottom: 16 }}>
              <CartesianGrid stroke="#1E293B" strokeDasharray="3 3" />
              <XAxis
                type="number"
                dataKey="angleDeg"
                name="Tilt Angle"
                unit="°"
                tick={{ fill: '#64748B', fontSize: 11 }}
                stroke="#253247"
                domain={['auto', 'auto']}
                label={{
                  value: 'Tilt Angle (°)',
                  position: 'insideBottom',
                  offset: -10,
                  fill: '#94A3B8',
                  fontSize: 11,
                }}
              />
              <YAxis
                type="number"
                dataKey="powerW"
                name="Power"
                unit="W"
                tick={{ fill: '#64748B', fontSize: 11 }}
                stroke="#253247"
                width={48}
                domain={[0, 'auto']}
              />
              <ZAxis range={[36, 36]} />
              <Tooltip
                cursor={{ strokeDasharray: '3 3', stroke: '#475569' }}
                contentStyle={{
                  backgroundColor: '#080D18',
                  borderColor: '#253247',
                  borderRadius: '8px',
                  fontSize: '12px',
                  color: '#F8FAFC',
                }}
                formatter={(val, name) => {
                  const num = Number(val ?? 0);
                  if (name === 'Tilt Angle') return [`${num.toFixed(1)}°`, 'Tilt Angle'];
                  return [`${num.toFixed(precision)} W`, 'Power'];
                }}
              />
              <Legend
                verticalAlign="top"
                height={24}
                wrapperStyle={{ fontSize: '11px', color: '#94A3B8' }}
              />
              <Scatter
                name="Observed Power"
                data={regularPoints}
                fill="#10B981"
                fillOpacity={0.78}
                isAnimationActive={false}
              />
              {peakPoints.length > 0 && (
                <Scatter
                  name="Peak Observed Power"
                  data={peakPoints}
                  fill="#FACC15"
                  isAnimationActive={false}
                />
              )}
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
};
