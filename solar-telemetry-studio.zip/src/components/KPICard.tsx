import React from 'react';

interface KPICardProps {
  title: string;
  value: string;
  unit: string;
  description: string;
  statusLabel: string;
  accentColor: string;
  statusTone?: 'live' | 'cached' | 'simulated' | 'waiting' | 'peak';
}

export const KPICard: React.FC<KPICardProps> = ({
  title,
  value,
  unit,
  description,
  statusLabel,
  accentColor,
  statusTone = 'waiting',
}) => {
  const statusColorClass =
    statusTone === 'live'
      ? 'text-emerald-400'
      : statusTone === 'peak'
      ? 'text-yellow-400'
      : statusTone === 'simulated'
      ? 'text-cyan-400'
      : statusTone === 'cached'
      ? 'text-amber-400'
      : 'text-slate-400';

  return (
    <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-4">
      <div className="flex items-center justify-between gap-2">
        <span className="truncate text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
          {title}
        </span>
        <span className={`shrink-0 whitespace-nowrap font-mono text-[11px] font-medium ${statusColorClass}`}>
          {statusLabel}
        </span>
      </div>

      <div className="mt-3 flex items-baseline gap-1.5">
        <span
          className="font-mono text-3xl font-bold tracking-tight tabular-nums"
          style={{ color: accentColor }}
        >
          {value}
        </span>
        <span className="font-mono text-sm font-medium text-slate-400">{unit}</span>
      </div>

      <p className="mt-2 truncate text-xs text-slate-400">{description}</p>
    </div>
  );
};
