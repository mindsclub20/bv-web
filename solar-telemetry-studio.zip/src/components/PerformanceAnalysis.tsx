import React, { useMemo, useState } from 'react';
import {
  Bar,
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { BarChart3, Info } from 'lucide-react';
import { ExperimentSession } from '../types/experiment';
import {
  computeAngleIntervalAnalysis,
  computeSessionStatistics,
} from '../utils/calculations';

interface PerformanceAnalysisProps {
  activeSession: ExperimentSession | null;
  experiments: ExperimentSession[];
  defaultIntervalDeg: number;
  precision: number;
}

export const PerformanceAnalysis: React.FC<PerformanceAnalysisProps> = ({
  activeSession,
  experiments,
  defaultIntervalDeg,
  precision,
}) => {
  const availableSessions = useMemo(() => {
    const list: ExperimentSession[] = [];
    if (activeSession && activeSession.samples.length > 0) {
      list.push(activeSession);
    }
    for (const exp of experiments) {
      if (!activeSession || exp.id !== activeSession.id) {
        list.push(exp);
      }
    }
    return list;
  }, [activeSession, experiments]);

  const [selectedSessionId, setSelectedSessionId] = useState<string>('');
  const [intervalDeg, setIntervalDeg] = useState<number>(defaultIntervalDeg);

  const targetSession = useMemo(() => {
    if (availableSessions.length === 0) return null;
    return (
      availableSessions.find((s) => s.id === selectedSessionId) ??
      availableSessions[0]
    );
  }, [availableSessions, selectedSessionId]);

  const stats = useMemo(
    () => computeSessionStatistics(targetSession?.samples ?? []),
    [targetSession]
  );

  const intervalBins = useMemo(
    () => computeAngleIntervalAnalysis(targetSession?.samples ?? [], intervalDeg, 1),
    [targetSession, intervalDeg]
  );

  if (!targetSession || stats.sampleCount === 0) {
    return (
      <div className="mx-auto max-w-5xl p-6">
        <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-10 text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl border border-[#253247] bg-[#080D18] text-amber-400">
            <BarChart3 className="h-6 w-6" aria-hidden="true" />
          </div>
          <h1 className="mt-4 text-xl font-bold text-slate-100">
            Solar Performance Analysis
          </h1>
          <p className="mx-auto mt-2 max-w-lg text-sm text-slate-400">
            Run a live screen-capture experiment or launch the Demo Simulator to record
            tilt angle, voltage, current, and power observations for interval analysis.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl space-y-6 p-6">
      {/* Header & Experiment Selector */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-50">
            Solar Performance Analysis
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Empirical comparison of measured solar electrical output across panel tilt
            angles.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div>
            <label
              htmlFor="analysis-session-select"
              className="mb-1 block text-[11px] font-medium text-slate-400"
            >
              Analyzed Experiment
            </label>
            <select
              id="analysis-session-select"
              value={targetSession.id}
              onChange={(e) => setSelectedSessionId(e.target.value)}
              className="rounded-lg border border-[#253247] bg-[#111C2D] px-3 py-2 text-xs font-medium text-slate-100 focus:border-amber-500 focus:outline-none"
            >
              {availableSessions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.mode === 'demo' ? 'Demo' : 'Real'} · {s.samples.length} samples)
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="angle-interval-select"
              className="mb-1 block text-[11px] font-medium text-slate-400"
            >
              Angle Bin Interval
            </label>
            <select
              id="angle-interval-select"
              value={intervalDeg}
              onChange={(e) => setIntervalDeg(Number(e.target.value))}
              className="rounded-lg border border-[#253247] bg-[#111C2D] px-3 py-2 text-xs font-medium text-slate-100 focus:border-amber-500 focus:outline-none"
            >
              <option value={5}>5° intervals</option>
              <option value={10}>10° intervals</option>
              <option value={15}>15° intervals</option>
              <option value={20}>20° intervals</option>
            </select>
          </div>
        </div>
      </div>

      {/* Summary Metrics Grid */}
      <section className="grid grid-cols-2 gap-4 md:grid-cols-4 lg:grid-cols-7">
        <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-4">
          <p className="text-[11px] font-medium text-slate-400">Peak Measured Power</p>
          <p className="mt-1.5 font-mono text-xl font-bold tabular-nums text-emerald-400">
            {stats.maxPowerW.toFixed(precision)} W
          </p>
        </div>
        <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-4">
          <p className="text-[11px] font-medium text-slate-400">Optimal Observed Angle</p>
          <p className="mt-1.5 font-mono text-xl font-bold tabular-nums text-[#FACC15]">
            {stats.peakObservedAngleDeg !== null
              ? `${stats.peakObservedAngleDeg.toFixed(1)}°`
              : '—'}
          </p>
        </div>
        <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-4">
          <p className="text-[11px] font-medium text-slate-400">Average Power</p>
          <p className="mt-1.5 font-mono text-xl font-bold tabular-nums text-slate-100">
            {stats.averagePowerW.toFixed(precision)} W
          </p>
        </div>
        <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-4">
          <p className="text-[11px] font-medium text-slate-400">Minimum Power</p>
          <p className="mt-1.5 font-mono text-xl font-bold tabular-nums text-slate-300">
            {stats.minPowerW.toFixed(precision)} W
          </p>
        </div>
        <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-4">
          <p className="text-[11px] font-medium text-slate-400">Maximum Power</p>
          <p className="mt-1.5 font-mono text-xl font-bold tabular-nums text-emerald-300">
            {stats.maxPowerW.toFixed(precision)} W
          </p>
        </div>
        <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-4">
          <p className="text-[11px] font-medium text-slate-400">Total Valid Samples</p>
          <p className="mt-1.5 font-mono text-xl font-bold tabular-nums text-cyan-400">
            {stats.sampleCount}
          </p>
        </div>
        <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-4">
          <p className="text-[11px] font-medium text-slate-400">Power Variation</p>
          <p className="mt-1.5 font-mono text-xl font-bold tabular-nums text-amber-400">
            {stats.powerVariationW.toFixed(precision)} W
          </p>
        </div>
      </section>

      {/* Peak Observation Summary & Methodology Note */}
      <section className="rounded-xl border border-[#253247] bg-[#0D1524] p-5">
        <div className="flex items-start gap-3">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-[#FACC15]" aria-hidden="true" />
          <div className="space-y-2 text-sm">
            <p className="font-semibold text-slate-100">
              Experiment Performance Summary
            </p>
            <p className="text-slate-300">
              The optimal observed angle is the angle that produced the highest measured
              power during this experiment.
              {stats.peakSample && (
                <>
                  {' '}
                  In <span className="font-medium text-slate-100">{targetSession.name}</span>,
                  peak power of{' '}
                  <span className="font-mono font-semibold text-emerald-400">
                    {stats.peakSample.powerW.toFixed(precision)} W
                  </span>{' '}
                  was observed at{' '}
                  <span className="font-mono font-semibold text-[#FACC15]">
                    {stats.peakSample.angleDeg.toFixed(1)}°
                  </span>{' '}
                  ({stats.peakSample.voltageV.toFixed(precision)} V ×{' '}
                  {stats.peakSample.currentA.toFixed(precision)} A at t ={' '}
                  {stats.peakSample.elapsedSeconds.toFixed(1)}s).
                </>
              )}
            </p>
          </div>
        </div>
      </section>

      {/* Angle vs Average Power Chart */}
      <section className="rounded-xl border border-[#253247] bg-[#111C2D] p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-semibold text-slate-100">
              Tilt Angle Interval vs Average Power ({intervalDeg}° Bins)
            </h2>
            <p className="text-xs text-slate-400">
              Solid green bars show direct measured interval averages. Dashed amber line
              shows linear interpolation only across unmeasured intermediate intervals.
            </p>
          </div>
        </div>

        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height={300}>
            <ComposedChart
              data={intervalBins}
              margin={{ top: 12, right: 20, left: 4, bottom: 16 }}
            >
              <CartesianGrid stroke="#1E293B" strokeDasharray="3 3" />
              <XAxis
                dataKey="label"
                tick={{ fill: '#94A3B8', fontSize: 11 }}
                stroke="#253247"
              />
              <YAxis
                tick={{ fill: '#94A3B8', fontSize: 11 }}
                stroke="#253247"
                width={52}
                unit="W"
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#080D18',
                  borderColor: '#253247',
                  borderRadius: '8px',
                  fontSize: '12px',
                  color: '#F8FAFC',
                }}
                formatter={(val, name) => [
                  val !== null ? `${Number(val).toFixed(precision)} W` : '—',
                  String(name),
                ]}
              />
              <Legend wrapperStyle={{ fontSize: '12px' }} />
              <Bar
                dataKey="measuredAveragePowerW"
                name="Measured Avg Power (W)"
                fill="#10B981"
                radius={[4, 4, 0, 0]}
                isAnimationActive={false}
              />
              <Line
                type="monotone"
                dataKey="interpolatedPowerW"
                name="Interpolated Estimate (W)"
                stroke="#F59E0B"
                strokeWidth={2}
                strokeDasharray="5 5"
                connectNulls={false}
                dot={{ r: 3, fill: '#F59E0B' }}
                isAnimationActive={false}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Interval Table */}
      <section className="overflow-hidden rounded-xl border border-[#253247] bg-[#111C2D]">
        <div className="border-b border-[#253247] px-5 py-3.5">
          <h2 className="text-sm font-semibold text-slate-100">
            Angle Interval Breakdown
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-[#253247] bg-[#0D1524] text-slate-400">
              <tr>
                <th className="px-4 py-3 font-semibold">Angle Interval</th>
                <th className="px-4 py-3 font-semibold">Samples</th>
                <th className="px-4 py-3 font-semibold">Measured Avg Power</th>
                <th className="px-4 py-3 font-semibold">Measured Max Power</th>
                <th className="px-4 py-3 font-semibold">Data Basis</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#253247]/60">
              {intervalBins.map((bin) => (
                <tr key={bin.label} className="hover:bg-[#0D1524]/50">
                  <td className="px-4 py-2.5 font-mono font-medium text-slate-100">
                    {bin.label}
                  </td>
                  <td className="px-4 py-2.5 font-mono tabular-nums text-slate-300">
                    {bin.sampleCount}
                  </td>
                  <td className="px-4 py-2.5 font-mono tabular-nums text-emerald-400">
                    {bin.measuredAveragePowerW !== null
                      ? `${bin.measuredAveragePowerW.toFixed(precision)} W`
                      : bin.interpolatedPowerW !== null
                      ? `${bin.interpolatedPowerW.toFixed(precision)} W`
                      : '—'}
                  </td>
                  <td className="px-4 py-2.5 font-mono tabular-nums text-slate-200">
                    {bin.measuredMaxPowerW !== null
                      ? `${bin.measuredMaxPowerW.toFixed(precision)} W`
                      : '—'}
                  </td>
                  <td className="px-4 py-2.5">
                    {bin.measuredAveragePowerW !== null ? (
                      <span className="font-medium text-emerald-400">
                        Direct Measurement
                      </span>
                    ) : bin.isInterpolated ? (
                      <span className="font-medium text-amber-400">
                        Interpolated Estimate
                      </span>
                    ) : (
                      <span className="text-slate-500">No Observations</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
