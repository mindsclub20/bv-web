import React from 'react';
import { RotateCcw, Undo2 } from 'lucide-react';
import {
  CALIBRATION_STEPS,
  CalibrationStepConfig,
  PartialCalibrationRegions,
} from '../types/calibration';

interface CalibrationBannerProps {
  currentStepIndex: 0 | 1 | 2 | 3;
  activeStepConfig: CalibrationStepConfig | null;
  regions: PartialCalibrationRegions;
  validationMessage: string | null;
  onUndo: () => void;
  onReset: () => void;
}

export const CalibrationBanner: React.FC<CalibrationBannerProps> = ({
  currentStepIndex,
  activeStepConfig,
  regions,
  validationMessage,
  onUndo,
  onReset,
}) => {
  const hasAnySelection = Boolean(regions.angle || regions.voltage || regions.current);

  return (
    <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-4">
      <div className="flex flex-wrap items-center justify-between gap-4">
        {/* Step Progress & Active Instruction */}
        <div className="flex min-w-0 flex-1 items-center gap-4">
          <div className="flex items-center gap-1.5 shrink-0" aria-label="Calibration step progress">
            {CALIBRATION_STEPS.map((step, idx) => {
              const isCompleted = Boolean(regions[step.metric]);
              const isCurrent = idx === currentStepIndex;
              return (
                <div
                  key={step.metric}
                  className="flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs font-medium"
                  style={{
                    borderColor: isCurrent || isCompleted ? step.color : '#253247',
                    backgroundColor: isCurrent
                      ? `${step.color}18`
                      : isCompleted
                      ? `${step.color}12`
                      : '#080D18',
                    color: isCurrent || isCompleted ? step.color : '#94A3B8',
                  }}
                >
                  <span className="font-mono font-bold">{step.stepNumber}</span>
                  <span className="hidden sm:inline">{step.label}</span>
                </div>
              );
            })}
          </div>

          <div className="min-w-0">
            {activeStepConfig ? (
              <div className="flex flex-wrap items-center gap-2">
                <span
                  className="font-mono text-xs font-semibold uppercase tracking-wider"
                  style={{ color: activeStepConfig.color }}
                >
                  Step {activeStepConfig.stepNumber} of 3
                </span>
                <span className="text-slate-600" aria-hidden="true">
                  ·
                </span>
                <p className="text-sm font-medium text-slate-100">
                  {activeStepConfig.instruction}
                </p>
              </div>
            ) : (
              <p className="text-sm font-medium text-emerald-400">
                All three telemetry regions calibrated. Starting live monitoring...
              </p>
            )}
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onUndo}
            disabled={!hasAnySelection}
            className="inline-flex items-center gap-1.5 rounded-md border border-[#253247] bg-[#080D18] px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:border-slate-500 disabled:opacity-40 whitespace-nowrap"
          >
            <Undo2 className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Undo Last</span>
          </button>

          <button
            type="button"
            onClick={onReset}
            disabled={!hasAnySelection}
            className="inline-flex items-center gap-1.5 rounded-md border border-[#253247] bg-[#080D18] px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:border-slate-500 disabled:opacity-40 whitespace-nowrap"
          >
            <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Recalibrate</span>
          </button>
        </div>
      </div>

      {validationMessage && (
        <p className="mt-2.5 text-xs font-medium text-rose-400" role="alert">
          {validationMessage}
        </p>
      )}
    </div>
  );
};
