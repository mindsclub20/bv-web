import React from 'react';
import {
  Activity,
  Camera,
  Compass,
  FileSpreadsheet,
  History,
  Monitor,
  Play,
  ScanText,
  Video,
  Zap,
} from 'lucide-react';

interface HeroScreenProps {
  onSelectScreen: () => void;
  onStartDemo: () => void;
  onViewHistory: () => void;
  experimentCount: number;
  isRequestingScreen: boolean;
  screenError: string | null;
}

const FEATURES = [
  {
    title: 'Real-Time Screen Capture',
    description:
      'Capture any mirrored Android window directly via the browser MediaDevices API while preserving native aspect ratio.',
    icon: Monitor,
    accentClass: 'text-cyan-400',
  },
  {
    title: 'Automatic OCR Measurement',
    description:
      'Local Tesseract.js worker extracts tilt angle, voltage, and current every 600ms with threshold binarization.',
    icon: ScanText,
    accentClass: 'text-amber-400',
  },
  {
    title: 'Live Power Calculation',
    description:
      'Continuously computes electrical output P = V × I with fault-tolerant sample retention and live KPI telemetry.',
    icon: Zap,
    accentClass: 'text-emerald-400',
  },
  {
    title: 'Solar Angle Optimization',
    description:
      'Correlates panel tilt angle with generated wattage, highlighting the peak observed operating angle in gold.',
    icon: Compass,
    accentClass: 'text-yellow-400',
  },
  {
    title: 'Experiment Recording',
    description:
      'Automatically records the shared display session to WebM in browser memory using MediaRecorder.',
    icon: Video,
    accentClass: 'text-rose-400',
  },
  {
    title: 'CSV and PNG Reports',
    description:
      'Export complete raw telemetry logs in RFC-compliant CSV alongside a high-resolution multi-chart PNG report.',
    icon: FileSpreadsheet,
    accentClass: 'text-cyan-400',
  },
];

export const HeroScreen: React.FC<HeroScreenProps> = ({
  onSelectScreen,
  onStartDemo,
  onViewHistory,
  experimentCount,
  isRequestingScreen,
  screenError,
}) => {
  return (
    <div className="mx-auto max-w-6xl space-y-8 p-6 lg:p-8">
      {/* Hero Header & Primary Actions */}
      <section className="rounded-xl border border-[#253247] bg-[#111C2D] p-6 lg:p-8">
        <div className="max-w-3xl space-y-3">
          <p className="font-mono text-xs font-semibold tracking-wider text-amber-400">
            LOCAL INSTRUMENTATION WORKBENCH
          </p>
          <h1 className="text-3xl font-bold tracking-tight text-slate-50 lg:text-4xl [text-wrap:balance]">
            Solar Performance Monitoring
          </h1>
          <p className="text-base leading-relaxed text-slate-300">
            Real-time solar panel tilt, voltage, current and power analysis.
          </p>
        </div>

        {screenError && (
          <div
            className="mt-5 rounded-lg border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-200"
            role="alert"
          >
            {screenError}
          </div>
        )}

        <div className="mt-6 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onSelectScreen}
            disabled={isRequestingScreen}
            className="inline-flex items-center gap-2.5 rounded-lg bg-[#F59E0B] px-5 py-3 text-sm font-semibold text-slate-950 transition-colors hover:bg-amber-400 disabled:opacity-60 whitespace-nowrap shrink-0"
          >
            <Camera className="h-4 w-4" aria-hidden="true" />
            <span>
              {isRequestingScreen
                ? 'Requesting Screen Access...'
                : 'SELECT MIRRORED ANDROID SCREEN'}
            </span>
          </button>

          <button
            type="button"
            onClick={onStartDemo}
            className="inline-flex items-center gap-2.5 rounded-lg border border-cyan-500/40 bg-cyan-500/10 px-5 py-3 text-sm font-semibold text-cyan-300 transition-colors hover:bg-cyan-500/20 whitespace-nowrap shrink-0"
          >
            <Play className="h-4 w-4" aria-hidden="true" />
            <span>TEST WITH DEMO SIMULATOR</span>
          </button>

          <button
            type="button"
            onClick={onViewHistory}
            className="inline-flex items-center gap-2.5 rounded-lg border border-[#253247] bg-[#0D1524] px-5 py-3 text-sm font-semibold text-slate-200 transition-colors hover:border-slate-500 hover:text-white whitespace-nowrap shrink-0"
          >
            <History className="h-4 w-4 text-slate-400" aria-hidden="true" />
            <span>VIEW PREVIOUS EXPERIMENTS</span>
            {experimentCount > 0 && (
              <span className="font-mono text-xs tabular-nums text-slate-400">
                ({experimentCount})
              </span>
            )}
          </button>
        </div>
      </section>

      {/* Feature Cards Grid */}
      <section aria-labelledby="capabilities-heading" className="space-y-4">
        <h2
          id="capabilities-heading"
          className="text-sm font-semibold tracking-wider text-slate-400"
        >
          INSTRUMENTATION CAPABILITIES
        </h2>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((feat) => {
            const Icon = feat.icon;
            return (
              <div
                key={feat.title}
                className="rounded-xl border border-[#253247] bg-[#111C2D] p-5"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[#253247] bg-[#080D18]">
                    <Icon className={`h-4 w-4 ${feat.accentClass}`} aria-hidden="true" />
                  </div>
                  <h3 className="text-base font-semibold text-slate-100">
                    {feat.title}
                  </h3>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-slate-400">
                  {feat.description}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Getting Started Guide */}
      <section
        aria-labelledby="guide-heading"
        className="rounded-xl border border-[#253247] bg-[#0D1524] p-6"
      >
        <div className="flex items-center gap-2.5">
          <Activity className="h-4 w-4 text-amber-400" aria-hidden="true" />
          <h2 id="guide-heading" className="text-base font-semibold text-slate-100">
            Getting Started Guide
          </h2>
        </div>
        <p className="mt-2 text-sm leading-relaxed text-slate-300">
          Your Android monitoring application must be mirrored onto this computer
          (via USB mirroring such as scrcpy, Vysor, or wireless screen cast) and
          must visibly display numerical readings for{' '}
          <span className="font-semibold text-amber-400">Tilt Angle (degrees)</span>,{' '}
          <span className="font-semibold text-cyan-400">Voltage (V)</span>, and{' '}
          <span className="font-semibold text-rose-400">Current (A)</span>.
        </p>

        <ol className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-3">
          <li className="rounded-lg border border-[#253247] bg-[#111C2D] p-4">
            <p className="font-mono text-xs font-semibold text-amber-400">01. Connect Display</p>
            <p className="mt-1.5 text-sm text-slate-300">
              Click Select Mirrored Android Screen and choose the window showing your
              live solar sensor readings.
            </p>
          </li>
          <li className="rounded-lg border border-[#253247] bg-[#111C2D] p-4">
            <p className="font-mono text-xs font-semibold text-cyan-400">02. Calibrate 3 Regions</p>
            <p className="mt-1.5 text-sm text-slate-300">
              Drag three boxes around the Angle, Voltage, and Current numbers.
              Telemetry and recording start automatically on the third box.
            </p>
          </li>
          <li className="rounded-lg border border-[#253247] bg-[#111C2D] p-4">
            <p className="font-mono text-xs font-semibold text-emerald-400">03. Analyze & Export</p>
            <p className="mt-1.5 text-sm text-slate-300">
              Sweep panel tilt angles to locate peak power output, then export your
              session video, CSV dataset, and PNG report.
            </p>
          </li>
        </ol>
      </section>
    </div>
  );
};
