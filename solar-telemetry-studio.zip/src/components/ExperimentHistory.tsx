import React, { useState } from 'react';
import {
  BarChart3,
  Download,
  Eye,
  History,
  Trash2,
  X,
} from 'lucide-react';
import { ExperimentSession } from '../types/experiment';
import { formatDuration } from '../utils/calculations';
import { downloadPngBlob, generateReportPngBlob } from '../utils/chartExporter';
import { downloadCsvBlob, generateTelemetryCsv } from '../utils/csvExporter';

interface ExperimentHistoryProps {
  experiments: ExperimentSession[];
  storageError: string | null;
  precision: number;
  onDeleteExperiment: (id: string) => void;
  onOpenInAnalysis: () => void;
}

export const ExperimentHistory: React.FC<ExperimentHistoryProps> = ({
  experiments,
  storageError,
  precision,
  onDeleteExperiment,
  onOpenInAnalysis,
}) => {
  const [selectedExperiment, setSelectedExperiment] =
    useState<ExperimentSession | null>(null);
  const [exportNote, setExportNote] = useState<string | null>(null);

  const handleExportCsv = (exp: ExperimentSession) => {
    const csv = generateTelemetryCsv(exp.samples, precision);
    downloadCsvBlob(csv, 'solar_panel_log.csv');
    setExportNote(`Exported CSV for "${exp.name}"`);
  };

  const handleExportPng = async (exp: ExperimentSession) => {
    setExportNote(`Generating PNG report for "${exp.name}"...`);
    const blob = await generateReportPngBlob(exp, precision);
    downloadPngBlob(blob, 'solar_panel_report.png');
    setExportNote(`Exported PNG report for "${exp.name}"`);
  };

  return (
    <div className="mx-auto max-w-6xl space-y-6 p-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-50">
            Experiment History
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Locally persisted solar telemetry sessions stored solely in this browser.
          </p>
        </div>

        <span className="font-mono text-xs tabular-nums text-slate-400">
          {experiments.length} saved {experiments.length === 1 ? 'experiment' : 'experiments'}
        </span>
      </div>

      {storageError && (
        <div
          className="rounded-xl border border-amber-500/40 bg-amber-500/10 p-4 text-sm text-amber-200"
          role="alert"
        >
          {storageError}
        </div>
      )}

      {exportNote && (
        <div
          className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-2.5 text-xs font-medium text-emerald-300"
          role="status"
        >
          {exportNote}
        </div>
      )}

      {experiments.length === 0 ? (
        <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-10 text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl border border-[#253247] bg-[#080D18] text-slate-400">
            <History className="h-6 w-6" aria-hidden="true" />
          </div>
          <h2 className="mt-4 text-lg font-semibold text-slate-100">
            No Saved Experiments Yet
          </h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-slate-400">
            When you stop a live OCR session or Demo Simulator run, the complete
            dataset, calibration regions, and peak power findings are saved here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {experiments.map((exp) => (
            <div
              key={exp.id}
              className="rounded-xl border border-[#253247] bg-[#111C2D] p-5"
            >
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <h2 className="text-base font-semibold text-slate-100">
                      {exp.name}
                    </h2>
                    <span
                      className={`font-mono text-xs font-medium ${
                        exp.mode === 'demo' ? 'text-cyan-400' : 'text-emerald-400'
                      }`}
                    >
                      {exp.mode === 'demo' ? 'Demo Simulator' : 'Live Capture'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    {new Date(exp.startedAtIso).toLocaleString()} · Duration{' '}
                    <span className="font-mono tabular-nums text-slate-300">
                      {formatDuration(exp.durationSeconds)}
                    </span>{' '}
                    ·{' '}
                    <span className="font-mono tabular-nums text-slate-300">
                      {exp.samples.length}
                    </span>{' '}
                    samples
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-6 font-mono text-xs">
                  <div>
                    <span className="block text-[11px] font-sans text-slate-400">
                      Peak Power
                    </span>
                    <span className="text-sm font-bold tabular-nums text-emerald-400">
                      {exp.peakPowerW.toFixed(precision)} W
                    </span>
                  </div>
                  <div>
                    <span className="block text-[11px] font-sans text-slate-400">
                      Optimal Angle
                    </span>
                    <span className="text-sm font-bold tabular-nums text-[#FACC15]">
                      {exp.peakObservedAngleDeg !== null
                        ? `${exp.peakObservedAngleDeg.toFixed(1)}°`
                        : '—'}
                    </span>
                  </div>
                  <div>
                    <span className="block text-[11px] font-sans text-slate-400">
                      Avg Power
                    </span>
                    <span className="text-sm font-bold tabular-nums text-slate-200">
                      {exp.averagePowerW.toFixed(precision)} W
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-[#253247] pt-3.5">
                <button
                  type="button"
                  onClick={() => setSelectedExperiment(exp)}
                  className="inline-flex items-center gap-1.5 rounded-md border border-[#253247] bg-[#080D18] px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-slate-500 whitespace-nowrap"
                >
                  <Eye className="h-3.5 w-3.5 text-cyan-400" aria-hidden="true" />
                  <span>View Summary</span>
                </button>

                <button
                  type="button"
                  onClick={onOpenInAnalysis}
                  className="inline-flex items-center gap-1.5 rounded-md border border-[#253247] bg-[#080D18] px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-slate-500 whitespace-nowrap"
                >
                  <BarChart3 className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
                  <span>Analyze Curves</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleExportCsv(exp)}
                  disabled={exp.samples.length === 0}
                  className="inline-flex items-center gap-1.5 rounded-md border border-[#253247] bg-[#080D18] px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-slate-500 disabled:opacity-40 whitespace-nowrap"
                >
                  <Download className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />
                  <span>CSV</span>
                </button>

                <button
                  type="button"
                  onClick={() => void handleExportPng(exp)}
                  disabled={exp.samples.length === 0}
                  className="inline-flex items-center gap-1.5 rounded-md border border-[#253247] bg-[#080D18] px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-slate-500 disabled:opacity-40 whitespace-nowrap"
                >
                  <Download className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
                  <span>PNG Report</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (selectedExperiment?.id === exp.id) {
                      setSelectedExperiment(null);
                    }
                    onDeleteExperiment(exp.id);
                  }}
                  aria-label={`Delete '${exp.name}'`}
                  className="ml-auto inline-flex items-center gap-1.5 rounded-md border border-rose-500/30 bg-rose-500/10 px-3 py-1.5 text-xs font-medium text-rose-300 hover:bg-rose-500/20 whitespace-nowrap"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Delete</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Selected Experiment Summary Modal/Panel */}
      {selectedExperiment && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="summary-dialog-title"
        >
          <div className="max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-xl border border-[#253247] bg-[#111C2D] p-6">
            <div className="flex items-start justify-between gap-4 border-b border-[#253247] pb-4">
              <div>
                <h2 id="summary-dialog-title" className="text-lg font-bold text-slate-100">
                  {selectedExperiment.name}
                </h2>
                <p className="mt-1 text-xs text-slate-400">
                  Started {new Date(selectedExperiment.startedAtIso).toLocaleString()} ·{' '}
                  {selectedExperiment.mode === 'demo'
                    ? 'Demo Simulator'
                    : 'Mirrored Screen OCR'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedExperiment(null)}
                className="rounded p-1.5 text-slate-400 hover:bg-[#080D18] hover:text-white"
                aria-label="Close experiment summary"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
              <div className="rounded-lg border border-[#253247] bg-[#080D18] p-3">
                <p className="text-[11px] text-slate-400">Peak Power</p>
                <p className="mt-1 font-mono text-base font-bold text-emerald-400">
                  {selectedExperiment.peakPowerW.toFixed(precision)} W
                </p>
              </div>
              <div className="rounded-lg border border-[#253247] bg-[#080D18] p-3">
                <p className="text-[11px] text-slate-400">Optimal Angle</p>
                <p className="mt-1 font-mono text-base font-bold text-[#FACC15]">
                  {selectedExperiment.peakObservedAngleDeg !== null
                    ? `${selectedExperiment.peakObservedAngleDeg.toFixed(1)}°`
                    : '—'}
                </p>
              </div>
              <div className="rounded-lg border border-[#253247] bg-[#080D18] p-3">
                <p className="text-[11px] text-slate-400">Average Power</p>
                <p className="mt-1 font-mono text-base font-bold text-slate-100">
                  {selectedExperiment.averagePowerW.toFixed(precision)} W
                </p>
              </div>
              <div className="rounded-lg border border-[#253247] bg-[#080D18] p-3">
                <p className="text-[11px] text-slate-400">Average Voltage</p>
                <p className="mt-1 font-mono text-base font-bold text-cyan-400">
                  {selectedExperiment.averageVoltageV.toFixed(precision)} V
                </p>
              </div>
              <div className="rounded-lg border border-[#253247] bg-[#080D18] p-3">
                <p className="text-[11px] text-slate-400">Average Current</p>
                <p className="mt-1 font-mono text-base font-bold text-rose-400">
                  {selectedExperiment.averageCurrentA.toFixed(precision)} A
                </p>
              </div>
              <div className="rounded-lg border border-[#253247] bg-[#080D18] p-3">
                <p className="text-[11px] text-slate-400">Duration</p>
                <p className="mt-1 font-mono text-base font-bold text-slate-100">
                  {formatDuration(selectedExperiment.durationSeconds)}
                </p>
              </div>
            </div>

            {selectedExperiment.calibrationRegions && (
              <div className="mt-4 rounded-lg border border-[#253247] bg-[#080D18] p-3.5">
                <p className="text-xs font-semibold text-slate-300">
                  Normalized Calibration Regions
                </p>
                <div className="mt-2 space-y-1 font-mono text-[11px] text-slate-400">
                  <p>
                    Angle: x={selectedExperiment.calibrationRegions.angle.x.toFixed(3)}, y=
                    {selectedExperiment.calibrationRegions.angle.y.toFixed(3)}, w=
                    {selectedExperiment.calibrationRegions.angle.width.toFixed(3)}, h=
                    {selectedExperiment.calibrationRegions.angle.height.toFixed(3)}
                  </p>
                  <p>
                    Voltage: x={selectedExperiment.calibrationRegions.voltage.x.toFixed(3)}, y=
                    {selectedExperiment.calibrationRegions.voltage.y.toFixed(3)}, w=
                    {selectedExperiment.calibrationRegions.voltage.width.toFixed(3)}, h=
                    {selectedExperiment.calibrationRegions.voltage.height.toFixed(3)}
                  </p>
                  <p>
                    Current: x={selectedExperiment.calibrationRegions.current.x.toFixed(3)}, y=
                    {selectedExperiment.calibrationRegions.current.y.toFixed(3)}, w=
                    {selectedExperiment.calibrationRegions.current.width.toFixed(3)}, h=
                    {selectedExperiment.calibrationRegions.current.height.toFixed(3)}
                  </p>
                </div>
              </div>
            )}

            <div className="mt-5 flex justify-end gap-2.5">
              <button
                type="button"
                onClick={() => handleExportCsv(selectedExperiment)}
                className="rounded-lg border border-cyan-500/40 bg-cyan-500/10 px-4 py-2 text-xs font-semibold text-cyan-300 hover:bg-cyan-500/20"
              >
                Export CSV
              </button>
              <button
                type="button"
                onClick={() => void handleExportPng(selectedExperiment)}
                className="rounded-lg bg-[#F59E0B] px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-amber-400"
              >
                Export PNG Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
