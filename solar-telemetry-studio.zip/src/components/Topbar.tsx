import React from 'react';
import { Menu, Settings, Sun } from 'lucide-react';
import { ConnectionStatus, RecordingStatus } from '../types/telemetry';
import { formatDuration } from '../utils/calculations';
import { RecordingIndicator } from './RecordingIndicator';

interface TopbarProps {
  sessionName: string;
  onSessionNameChange: (name: string) => void;
  connectionStatus: ConnectionStatus;
  elapsedSeconds: number;
  recordingStatus: RecordingStatus;
  recordingDurationSeconds: number;
  onOpenSettings: () => void;
  onOpenMobileNav: () => void;
}

const CONNECTION_STATUS_MAP: Record<
  ConnectionStatus,
  { label: string; colorClass: string }
> = {
  disconnected: { label: 'Disconnected', colorClass: 'text-slate-400' },
  requesting: { label: 'Awaiting Screen Permission', colorClass: 'text-amber-400' },
  connected: { label: 'Screen Connected', colorClass: 'text-cyan-400' },
  calibrating: { label: 'Calibrating Regions', colorClass: 'text-amber-400' },
  monitoring: { label: 'Live OCR Active', colorClass: 'text-emerald-400' },
  paused: { label: 'Monitoring Paused', colorClass: 'text-amber-400' },
  demo: { label: 'Demo Simulator Active', colorClass: 'text-cyan-400' },
  error: { label: 'Capture Error', colorClass: 'text-rose-400' },
};

export const Topbar: React.FC<TopbarProps> = ({
  sessionName,
  onSessionNameChange,
  connectionStatus,
  elapsedSeconds,
  recordingStatus,
  recordingDurationSeconds,
  onOpenSettings,
  onOpenMobileNav,
}) => {
  const statusInfo = CONNECTION_STATUS_MAP[connectionStatus];

  return (
    <header className="flex h-16 shrink-0 items-center justify-between gap-4 border-b border-[#253247] bg-[#0D1524] px-4 lg:px-6">
      {/* Left: Brand & Session Name */}
      <div className="flex min-w-0 items-center gap-3">
        <button
          type="button"
          onClick={onOpenMobileNav}
          className="rounded-md border border-[#253247] bg-[#111C2D] p-2 text-slate-300 hover:text-white lg:hidden"
          aria-label="Open navigation menu"
        >
          <Menu className="h-4 w-4" />
        </button>

        <div className="flex items-center gap-2 whitespace-nowrap shrink-0 lg:hidden">
          <Sun className="h-4 w-4 text-amber-400" aria-hidden="true" />
          <span className="text-sm font-bold tracking-tight text-slate-100">
            SOLAR TELEMETRY STUDIO
          </span>
        </div>

        <div className="hidden min-w-0 items-center gap-2.5 sm:flex">
          <span className="hidden text-xs font-semibold tracking-wider text-slate-400 xl:inline whitespace-nowrap">
            SOLAR TELEMETRY STUDIO
          </span>
          <span className="hidden text-slate-600 xl:inline" aria-hidden="true">
            /
          </span>
          <label htmlFor="session-name-input" className="sr-only">
            Current Session Name
          </label>
          <input
            id="session-name-input"
            type="text"
            value={sessionName}
            onChange={(e) => onSessionNameChange(e.target.value)}
            className="w-64 truncate rounded-md border border-[#253247] bg-[#080D18] px-3 py-1.5 text-sm font-medium text-slate-100 placeholder-slate-500 focus:border-amber-500 focus:outline-none sm:w-72"
            placeholder="Experiment Session Name"
          />
        </div>
      </div>

      {/* Right: Connection Status, Session Timer, Recording Indicator, Settings */}
      <div className="flex shrink-0 items-center gap-4 md:gap-6">
        <div className="hidden items-center gap-2 text-xs md:flex whitespace-nowrap">
          <span className="text-slate-400">Status:</span>
          <span className={`font-medium ${statusInfo.colorClass}`}>
            {statusInfo.label}
          </span>
        </div>

        <div className="flex items-center gap-2 border-l border-[#253247] pl-4 text-xs whitespace-nowrap">
          <span className="hidden text-slate-400 sm:inline">Session Timer</span>
          <span
            className="font-mono text-sm font-semibold tabular-nums text-slate-100"
            data-testid="session-timer"
          >
            {formatDuration(elapsedSeconds)}
          </span>
        </div>

        <RecordingIndicator
          status={recordingStatus}
          durationSeconds={recordingDurationSeconds}
        />

        <button
          type="button"
          onClick={onOpenSettings}
          className="flex h-9 w-9 items-center justify-center rounded-md border border-[#253247] bg-[#111C2D] text-slate-300 transition-colors hover:border-slate-500 hover:text-white"
          aria-label="Open Settings"
          title="Settings"
        >
          <Settings className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
};
