import React from 'react';
import {
  Activity,
  BarChart3,
  Crosshair,
  Download,
  History,
  LayoutDashboard,
  Settings,
  Sun,
  X,
} from 'lucide-react';
import { isMediaRecorderSupported } from '../services/recordingService';
import { AppSection } from '../types/telemetry';

interface SidebarProps {
  activeSection: AppSection;
  onSelectSection: (section: AppSection) => void;
  hasActiveSession: boolean;
  experimentCount: number;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

interface NavItem {
  id: AppSection;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeSection,
  onSelectSection,
  hasActiveSession,
  experimentCount,
  isOpenMobile,
  onCloseMobile,
}) => {
  const displayCaptureSupported =
    typeof navigator !== 'undefined' &&
    Boolean(navigator.mediaDevices && typeof navigator.mediaDevices.getDisplayMedia === 'function');
  const recorderSupported = isMediaRecorderSupported();

  const navItems: NavItem[] = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    {
      id: 'live-monitoring',
      label: 'Live Monitoring',
      icon: Activity,
      badge: hasActiveSession ? 'Active' : undefined,
    },
    { id: 'screen-calibration', label: 'Screen Calibration', icon: Crosshair },
    {
      id: 'experiment-history',
      label: 'Experiment History',
      icon: History,
      badge: experimentCount > 0 ? String(experimentCount) : undefined,
    },
    { id: 'performance-analysis', label: 'Performance Analysis', icon: BarChart3 },
    { id: 'reports-exports', label: 'Reports & Exports', icon: Download },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const handleNav = (id: AppSection) => {
    onSelectSection(id);
    onCloseMobile();
  };

  return (
    <>
      {isOpenMobile && (
        <div
          className="fixed inset-0 z-40 bg-black/60 lg:hidden"
          onClick={onCloseMobile}
          aria-hidden="true"
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-64 shrink-0 flex-col border-r border-[#253247] bg-[#0D1524] transition-transform duration-200 lg:static lg:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
        aria-label="Primary Sidebar Navigation"
      >
        {/* Brand Block */}
        <div className="flex h-16 items-center justify-between border-b border-[#253247] px-5">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-md border border-amber-500/30 bg-amber-500/10 text-amber-400">
              <Sun className="h-4 w-4" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <p className="truncate text-xs font-bold tracking-wider text-slate-100">
                SOLAR TELEMETRY
              </p>
              <p className="truncate text-[11px] font-medium text-slate-400">
                Studio Workbench
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onCloseMobile}
            className="rounded p-1.5 text-slate-400 hover:bg-[#111C2D] hover:text-slate-100 lg:hidden"
            aria-label="Close navigation menu"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4" aria-label="Workspace Sections">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNav(item.id)}
                className={`flex w-full items-center justify-between rounded-md px-3 py-2.5 text-left text-sm font-medium transition-colors whitespace-nowrap ${
                  isActive
                    ? 'border border-[#253247] bg-[#111C2D] text-amber-400'
                    : 'border border-transparent text-slate-300 hover:bg-[#111C2D]/60 hover:text-slate-100'
                }`}
                aria-current={isActive ? 'page' : undefined}
              >
                <span className="flex items-center gap-2.5 truncate">
                  <Icon
                    className={`h-4 w-4 shrink-0 ${
                      isActive ? 'text-amber-400' : 'text-slate-400'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </span>
                {item.badge && (
                  <span className="ml-2 font-mono text-xs tabular-nums text-slate-400">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Sidebar Footer */}
        <div className="border-t border-[#253247] bg-[#080D18]/60 px-4 py-3.5 text-xs text-slate-400">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Local Processing</span>
              <span className="font-mono text-emerald-400">Browser Only</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Browser Compatibility</span>
              <span
                className={`font-mono ${
                  displayCaptureSupported && recorderSupported
                    ? 'text-cyan-400'
                    : 'text-amber-400'
                }`}
              >
                {displayCaptureSupported && recorderSupported ? 'Full API' : 'Partial API'}
              </span>
            </div>
            <div className="flex items-center justify-between border-t border-[#253247]/60 pt-1.5 text-[11px] text-slate-500">
              <span>Application Version</span>
              <span className="font-mono tabular-nums">v1.0.0</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
