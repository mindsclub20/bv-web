import React from 'react';
import {
  CALIBRATION_STEPS,
  CalibrationStepConfig,
  PartialCalibrationRegions,
} from '../types/calibration';
import { PixelRect } from '../utils/calculations';

interface RegionSelectorProps {
  regions: PartialCalibrationRegions;
  activeStepConfig: CalibrationStepConfig | null;
  activeDraftRect: PixelRect | null;
  onPointerDown: (e: React.PointerEvent<HTMLDivElement>) => void;
  onPointerMove: (e: React.PointerEvent<HTMLDivElement>) => void;
  onPointerUp: (e: React.PointerEvent<HTMLDivElement>) => void;
}

export const RegionSelector: React.FC<RegionSelectorProps> = ({
  regions,
  activeStepConfig,
  activeDraftRect,
  onPointerDown,
  onPointerMove,
  onPointerUp,
}) => {
  const activeColor = activeStepConfig?.color ?? '#10B981';

  return (
    <div
      data-testid="region-selector-overlay"
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      className="absolute inset-0 z-10 select-none touch-none cursor-crosshair"
      role="application"
      aria-label={
        activeStepConfig
          ? `Calibration canvas: ${activeStepConfig.instruction}`
          : 'Calibration canvas complete'
      }
    >
      {/* Completed normalized region overlays */}
      {CALIBRATION_STEPS.map((step) => {
        const reg = regions[step.metric];
        if (!reg) return null;
        return (
          <div
            key={step.metric}
            style={{
              left: `${reg.x * 100}%`,
              top: `${reg.y * 100}%`,
              width: `${reg.width * 100}%`,
              height: `${reg.height * 100}%`,
              borderColor: step.color,
              backgroundColor: `${step.color}20`,
            }}
            className="pointer-events-none absolute border-2"
          >
            <span
              style={{ backgroundColor: step.color }}
              className="absolute -top-6 left-0 rounded px-1.5 py-0.5 font-mono text-[11px] font-bold text-slate-950 whitespace-nowrap"
            >
              {step.stepNumber}. {step.label.toUpperCase()} ({step.unit})
            </span>
          </div>
        );
      })}

      {/* Live drag rectangle */}
      {activeDraftRect && activeDraftRect.width > 1 && activeDraftRect.height > 1 && (
        <div
          style={{
            left: `${activeDraftRect.x}px`,
            top: `${activeDraftRect.y}px`,
            width: `${activeDraftRect.width}px`,
            height: `${activeDraftRect.height}px`,
            borderColor: activeColor,
            backgroundColor: `${activeColor}26`,
          }}
          className="pointer-events-none absolute border-2 border-dashed"
        >
          <span
            style={{ backgroundColor: activeColor }}
            className="absolute -top-6 left-0 rounded px-1.5 py-0.5 font-mono text-[11px] font-bold text-slate-950 whitespace-nowrap"
          >
            {Math.round(activeDraftRect.width)}×{Math.round(activeDraftRect.height)}px
          </span>
        </div>
      )}
    </div>
  );
};
