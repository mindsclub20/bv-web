import React, { useState } from 'react';
import { RotateCcw, ShieldCheck, Trash2 } from 'lucide-react';
import { TESSERACT_CDN_CONFIG } from '../services/ocrService';
import { AppSettings, DEFAULT_APP_SETTINGS } from '../types/telemetry';

interface SettingsPanelProps {
  settings: AppSettings;
  experimentCount: number;
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
  onClearHistory: () => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({
  settings,
  experimentCount,
  onUpdateSettings,
  onClearHistory,
}) => {
  const [confirmClear, setConfirmClear] = useState(false);
  const [clearedMessage, setClearedMessage] = useState<string | null>(null);

  const handleConfirmClear = () => {
    onClearHistory();
    setConfirmClear(false);
    setClearedMessage('All local experiment history has been cleared.');
  };

  return (
    <div className="mx-auto max-w-4xl space-y-6 p-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-50">
            Studio Settings
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Configure local OCR sampling, computer vision preprocessing, chart windowing,
            and browser storage.
          </p>
        </div>

        <button
          type="button"
          onClick={() => onUpdateSettings(DEFAULT_APP_SETTINGS)}
          className="inline-flex items-center gap-2 rounded-lg border border-[#253247] bg-[#111C2D] px-3.5 py-2 text-xs font-semibold text-slate-200 hover:border-slate-500 whitespace-nowrap"
        >
          <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Reset to Defaults</span>
        </button>
      </div>

      {/* OCR & Computer Vision Settings */}
      <section className="rounded-xl border border-[#253247] bg-[#111C2D] p-6 space-y-5">
        <h2 className="text-base font-semibold text-slate-100">
          OCR & Image Preprocessing
        </h2>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <div>
            <div className="flex items-center justify-between">
              <label
                htmlFor="setting-ocr-interval"
                className="text-sm font-medium text-slate-200"
              >
                OCR Sampling Interval
              </label>
              <span className="font-mono text-xs font-semibold tabular-nums text-amber-400">
                {settings.ocrIntervalMs} ms
              </span>
            </div>
            <input
              id="setting-ocr-interval"
              type="range"
              min={300}
              max={2000}
              step={50}
              value={settings.ocrIntervalMs}
              onChange={(e) =>
                onUpdateSettings({ ocrIntervalMs: Number(e.target.value) })
              }
              className="mt-2 w-full cursor-pointer accent-amber-500"
            />
            <p className="mt-1 text-xs text-slate-400">
              Default is 600ms. Cycles skip automatically if the previous OCR read is
              still running.
            </p>
          </div>

          <div>
            <div className="flex items-center justify-between">
              <label
                htmlFor="setting-contrast"
                className="text-sm font-medium text-slate-200"
              >
                Contrast Threshold
              </label>
              <span className="font-mono text-xs font-semibold tabular-nums text-cyan-400">
                {settings.contrastThreshold}
              </span>
            </div>
            <input
              id="setting-contrast"
              type="range"
              min={20}
              max={235}
              step={1}
              value={settings.contrastThreshold}
              onChange={(e) =>
                onUpdateSettings({ contrastThreshold: Number(e.target.value) })
              }
              className="mt-2 w-full cursor-pointer accent-cyan-500"
            />
            <p className="mt-1 text-xs text-slate-400">
              Binarization cutoff (0–255) applied after grayscale contrast stretching.
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between border-t border-[#253247] pt-4">
          <div>
            <label
              htmlFor="setting-invert-toggle"
              className="text-sm font-medium text-slate-200"
            >
              Invert Dark/Light Display
            </label>
            <p className="text-xs text-slate-400">
              Enable when your Android solar app displays white/bright digits on a dark
              background.
            </p>
          </div>
          <input
            id="setting-invert-toggle"
            type="checkbox"
            checked={settings.invertDisplay}
            onChange={(e) =>
              onUpdateSettings({ invertDisplay: e.target.checked })
            }
            className="h-5 w-5 cursor-pointer accent-amber-500"
          />
        </div>
      </section>

      {/* Telemetry Display & Simulator Settings */}
      <section className="rounded-xl border border-[#253247] bg-[#111C2D] p-6 space-y-5">
        <h2 className="text-base font-semibold text-slate-100">
          Telemetry Display & Analysis
        </h2>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          <div>
            <label
              htmlFor="setting-chart-window"
              className="block text-sm font-medium text-slate-200"
            >
              Chart Display Window
            </label>
            <select
              id="setting-chart-window"
              value={settings.chartWindowSamples}
              onChange={(e) =>
                onUpdateSettings({ chartWindowSamples: Number(e.target.value) })
              }
              className="mt-2 w-full rounded-lg border border-[#253247] bg-[#080D18] px-3 py-2 text-sm text-slate-100 focus:border-amber-500 focus:outline-none"
            >
              <option value={60}>Last 60 samples</option>
              <option value={120}>Last 120 samples</option>
              <option value={240}>Last 240 samples</option>
              <option value={500}>Last 500 samples</option>
            </select>
            <p className="mt-1 text-xs text-slate-400">
              Full experiment data is always preserved for export.
            </p>
          </div>

          <div>
            <label
              htmlFor="setting-precision"
              className="block text-sm font-medium text-slate-200"
            >
              Numeric Precision
            </label>
            <select
              id="setting-precision"
              value={settings.numericPrecision}
              onChange={(e) =>
                onUpdateSettings({ numericPrecision: Number(e.target.value) })
              }
              className="mt-2 w-full rounded-lg border border-[#253247] bg-[#080D18] px-3 py-2 text-sm text-slate-100 focus:border-amber-500 focus:outline-none"
            >
              <option value={1}>1 decimal place</option>
              <option value={2}>2 decimal places</option>
              <option value={3}>3 decimal places</option>
            </select>
          </div>

          <div>
            <label
              htmlFor="setting-demo-peak"
              className="block text-sm font-medium text-slate-200"
            >
              Demo Simulator Peak Angle
            </label>
            <input
              id="setting-demo-peak"
              type="number"
              min={10}
              max={75}
              value={settings.demoPeakAngleDeg}
              onChange={(e) =>
                onUpdateSettings({
                  demoPeakAngleDeg: Math.max(10, Math.min(75, Number(e.target.value) || 34)),
                })
              }
              className="mt-2 w-full rounded-lg border border-[#253247] bg-[#080D18] px-3 py-2 font-mono text-sm text-slate-100 focus:border-amber-500 focus:outline-none"
            />
          </div>
        </div>
      </section>

      {/* Experiment Storage Management */}
      <section className="rounded-xl border border-[#253247] bg-[#111C2D] p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-100">
              Experiment Storage Management
            </h2>
            <p className="mt-1 text-xs text-slate-400">
              Currently storing{' '}
              <span className="font-mono font-semibold text-slate-200">
                {experimentCount}
              </span>{' '}
              saved {experimentCount === 1 ? 'session' : 'sessions'} in browser
              localStorage.
            </p>
          </div>

          {!confirmClear ? (
            <button
              type="button"
              onClick={() => {
                setClearedMessage(null);
                setConfirmClear(true);
              }}
              disabled={experimentCount === 0}
              className="inline-flex items-center gap-2 rounded-lg border border-rose-500/40 bg-rose-500/10 px-4 py-2 text-xs font-semibold text-rose-300 hover:bg-rose-500/20 disabled:opacity-40 whitespace-nowrap"
            >
              <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Clear Local Experiment History</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleConfirmClear}
                className="rounded-lg bg-rose-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-rose-500 whitespace-nowrap"
              >
                Confirm Delete All
              </button>
              <button
                type="button"
                onClick={() => setConfirmClear(false)}
                className="rounded-lg border border-[#253247] bg-[#080D18] px-3.5 py-2 text-xs font-semibold text-slate-300 hover:text-white whitespace-nowrap"
              >
                Cancel
              </button>
            </div>
          )}
        </div>

        {clearedMessage && (
          <p className="text-xs font-medium text-emerald-400" role="status">
            {clearedMessage}
          </p>
        )}
      </section>

      {/* Application Information & Zero-API-Key Transparency */}
      <section className="rounded-xl border border-[#253247] bg-[#0D1524] p-6 space-y-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-emerald-400" aria-hidden="true" />
          <h2 className="text-base font-semibold text-slate-100">
            Application Information & Local Execution Policy
          </h2>
        </div>
        <p className="text-sm leading-relaxed text-slate-300">
          Solar Telemetry Studio runs 100% locally in your browser with zero external
          API keys, zero cloud AI inference, and zero remote data transmission.
        </p>
        <div className="rounded-lg border border-[#253247] bg-[#080D18] p-3.5 text-xs text-slate-400 space-y-1.5">
          <p className="font-semibold text-slate-300">
            Transparent CDN Dependency Notice (Tesseract.js OCR)
          </p>
          <p>
            When OCR runs for the first time in a browser session, Tesseract worker
            scripts, WASM core, and English language data are fetched from public CDNs
            until cached by your browser:
          </p>
          <p className="font-mono text-[11px] text-slate-500 break-all">
            Worker: {TESSERACT_CDN_CONFIG.workerPath}
          </p>
          <p className="font-mono text-[11px] text-slate-500 break-all">
            LangData: {TESSERACT_CDN_CONFIG.langPath}
          </p>
        </div>
      </section>
    </div>
  );
};
