import React from 'react';
import {
  Crosshair,
  Pause,
  Play,
  Square,
  SunMoon,
} from 'lucide-react';
import { ExperimentMode } from '../types/experiment';

interface ControlToolbarProps {
  mode: ExperimentMode;
  isPaused: boolean;
  contrastThreshold: number;
  invertDisplay: boolean;
  onPause: () => void;
  onResume: () => void;
  onToggleInvert: () => void;
  onContrastChange: (value: number) => void;
  onRedrawBoxes: () => void;
  onStopAndExport: () => void;
}

export const ControlToolbar: React.FC<ControlToolbarProps> = ({
  mode,
  isPaused,
  contrastThreshold,
  invertDisplay,
  onPause,
  onResume,
  onToggleInvert,
  onContrastChange,
  onRedrawBoxes,
  onStopAndExport,
}) => {
  return (
    <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-4">
      <div className="flex flex-wrap items-center justify-between gap-4">
        {/* Left: Pause/Resume & Redraw */}
        <div className="flex flex-wrap items-center gap-2.5">
          {isPaused ? (
            <button
              type="button"
              onClick={onResume}
              className="inline-flex items-center gap-2 rounded-lg bg-emerald-500 px-4 py-2 text-xs font-semibold text-slate-950 transition-colors hover:bg-emerald-400 whitespace-nowrap"
            >
              <Play className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Resume Monitoring</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={onPause}
              className="inline-flex items-center gap-2 rounded-lg border border-amber-500/40 bg-amber-500/15 px-4 py-2 text-xs font-semibold text-amber-300 transition-colors hover:bg-amber-500/25 whitespace-nowrap"
            >
              <Pause className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Pause Monitoring</span>
            </button>
          )}

          {mode === 'real' && (
            <button
              type="button"
              onClick={onRedrawBoxes}
              className="inline-flex items-center gap-2 rounded-lg border border-[#253247] bg-[#080D18] px-3.5 py-2 text-xs font-semibold text-slate-200 transition-colors hover:border-slate-500 whitespace-nowrap"
            >
              <Crosshair className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
              <span>Re-draw Boxes</span>
            </button>
          )}
        </div>

        {/* Center: OCR Image Preprocessing Controls */}
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2.5">
            <label
              htmlFor="toolbar-contrast-slider"
              className="text-xs font-medium text-slate-300 whitespace-nowrap"
            >
              Contrast Threshold
            </label>
            <input
              id="toolbar-contrast-slider"
              type="range"
              min={20}
              max={235}
              step={1}
              value={contrastThreshold}
              onChange={(e) => onContrastChange(Number(e.target.value))}
              className="h-1.5 w-28 cursor-pointer accent-amber-500"
            />
            <span className="w-8 font-mono text-xs tabular-nums text-slate-300">
              {contrastThreshold}
            </span>
          </div>

          <button
            type="button"
            onClick={onToggleInvert}
            aria-pressed={invertDisplay}
            className={`inline-flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
              invertDisplay
                ? 'border-cyan-500/50 bg-cyan-500/15 text-cyan-300'
                : 'border-[#253247] bg-[#080D18] text-slate-300 hover:border-slate-500'
            }`}
          >
            <SunMoon className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Invert Dark/Light Display: {invertDisplay ? 'ON' : 'OFF'}</span>
          </button>
        </div>

        {/* Right: Stop & Export */}
        <button
          type="button"
          onClick={onStopAndExport}
          className="inline-flex items-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-rose-500 whitespace-nowrap"
        >
          <Square className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Stop & Export Results</span>
        </button>
      </div>
    </div>
  );
};
