import React from 'react';
import { RecordingStatus } from '../types/telemetry';
import { formatDuration } from '../utils/calculations';

interface RecordingIndicatorProps {
  status: RecordingStatus;
  durationSeconds: number;
}

export const RecordingIndicator: React.FC<RecordingIndicatorProps> = ({
  status,
  durationSeconds,
}) => {
  if (status === 'idle') {
    return null;
  }

  if (status === 'recording') {
    return (
      <div
        className="flex items-center gap-2 rounded-md border border-rose-500/40 bg-rose-500/10 px-2.5 py-1 text-xs font-semibold text-rose-400 whitespace-nowrap shrink-0"
        role="status"
        aria-label={`Recording active ${formatDuration(durationSeconds)}`}
      >
        <span className="h-2 w-2 rounded-full bg-rose-500 animate-pulse" aria-hidden="true" />
        <span className="font-mono tracking-wider">REC</span>
        <span className="font-mono tabular-nums text-rose-300">
          {formatDuration(durationSeconds)}
        </span>
      </div>
    );
  }

  if (status === 'stopped') {
    return (
      <div className="flex items-center gap-1.5 rounded-md border border-[#253247] bg-[#111C2D] px-2.5 py-1 text-xs font-medium text-slate-300 whitespace-nowrap shrink-0">
        <span>Video Saved</span>
        <span className="font-mono tabular-nums text-slate-400">
          {formatDuration(durationSeconds)}
        </span>
      </div>
    );
  }

  if (status === 'unsupported' || status === 'error') {
    return (
      <div className="flex items-center gap-1.5 rounded-md border border-amber-500/30 bg-amber-500/10 px-2.5 py-1 text-xs font-medium text-amber-300 whitespace-nowrap shrink-0">
        <span>{status === 'unsupported' ? 'REC Unsupported' : 'REC Error'}</span>
      </div>
    );
  }

  return null;
};
