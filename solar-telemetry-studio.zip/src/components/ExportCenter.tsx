import React, { useMemo, useState } from 'react';
import {
  CheckCircle2,
  Download,
  FileSpreadsheet,
  Image as ImageIcon,
  Video,
} from 'lucide-react';
import {
  downloadVideoBlob,
  getRecordingFilename,
} from '../services/recordingService';
import { ExperimentSession } from '../types/experiment';
import { RecordingStatus } from '../types/telemetry';
import { formatDuration } from '../utils/calculations';
import { downloadPngBlob, generateReportPngBlob } from '../utils/chartExporter';
import { downloadCsvBlob, generateTelemetryCsv } from '../utils/csvExporter';

interface ExportCenterProps {
  session: ExperimentSession | null;
  experiments: ExperimentSession[];
  recordedBlob: Blob | null;
  recordingMimeType: string | null;
  recordingStatus: RecordingStatus;
  recordingError: string | null;
  precision: number;
}

export const ExportCenter: React.FC<ExportCenterProps> = ({
  session,
  experiments,
  recordedBlob,
  recordingMimeType,
  recordingStatus,
  recordingError,
  precision,
}) => {
  const [selectedId, setSelectedId] = useState<string>('');
  const [csvStatus, setCsvStatus] = useState<string | null>(null);
  const [pngStatus, setPngStatus] = useState<string | null>(null);
  const [pngGenerating, setPngGenerating] = useState(false);
  const [videoStatus, setVideoStatus] = useState<string | null>(null);

  const availableSessions = useMemo(() => {
    const list: ExperimentSession[] = [];
    if (session) list.push(session);
    for (const exp of experiments) {
      if (!session || exp.id !== session.id) {
        list.push(exp);
      }
    }
    return list;
  }, [session, experiments]);

  const targetSession = useMemo(() => {
    if (availableSessions.length === 0) return null;
    return availableSessions.find((s) => s.id === selectedId) ?? availableSessions[0];
  }, [availableSessions, selectedId]);

  const isLiveSessionSelected =
    Boolean(session && targetSession && session.id === targetSession.id);
  const activeVideoBlob = isLiveSessionSelected ? recordedBlob : null;
  const videoFilename = getRecordingFilename(recordingMimeType);

  const csvPreview = useMemo(() => {
    if (!targetSession || targetSession.samples.length === 0) return '';
    const full = generateTelemetryCsv(targetSession.samples.slice(0, 4), precision);
    return full;
  }, [targetSession, precision]);

  const handleDownloadVideo = () => {
    if (!activeVideoBlob) return;
    downloadVideoBlob(activeVideoBlob, videoFilename);
    setVideoStatus(`Downloaded ${videoFilename}`);
  };

  const handleDownloadCsv = () => {
    if (!targetSession || targetSession.samples.length === 0) return;
    const csv = generateTelemetryCsv(targetSession.samples, precision);
    downloadCsvBlob(csv, 'solar_panel_log.csv');
    setCsvStatus(`Downloaded solar_panel_log.csv (${targetSession.samples.length} rows)`);
  };

  const handleDownloadPng = async () => {
    if (!targetSession) return;
    setPngGenerating(true);
    setPngStatus('Rendering high-resolution 4-chart PNG report...');
    try {
      const blob = await generateReportPngBlob(targetSession, precision);
      downloadPngBlob(blob, 'solar_panel_report.png');
      setPngStatus('Downloaded solar_panel_report.png (2400 × 1560px)');
    } catch (err) {
      setPngStatus(
        err instanceof Error ? `Export failed: ${err.message}` : 'PNG generation failed.'
      );
    } finally {
      setPngGenerating(false);
    }
  };

  if (!targetSession) {
    return (
      <div className="mx-auto max-w-5xl p-6">
        <div className="rounded-xl border border-[#253247] bg-[#111C2D] p-10 text-center">
          <h1 className="text-xl font-bold text-slate-100">Reports & Export Center</h1>
          <p className="mx-auto mt-2 max-w-lg text-sm text-slate-400">
            Complete a live monitoring or demo simulator session to generate CSV logs,
            multi-chart PNG reports, and session video exports.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl space-y-6 p-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-50">
            Reports & Export Center
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Download locally generated session recordings, raw CSV telemetry logs, and
            publication-ready PNG chart reports.
          </p>
        </div>

        <div>
          <label
            htmlFor="export-session-select"
            className="mb-1 block text-[11px] font-medium text-slate-400"
          >
            Export Target Session
          </label>
          <select
            id="export-session-select"
            value={targetSession.id}
            onChange={(e) => {
              setSelectedId(e.target.value);
              setCsvStatus(null);
              setPngStatus(null);
              setVideoStatus(null);
            }}
            className="rounded-lg border border-[#253247] bg-[#111C2D] px-3 py-2 text-xs font-medium text-slate-100 focus:border-amber-500 focus:outline-none"
          >
            {availableSessions.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.samples.length} samples)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Session Summary Banner */}
      <div className="grid grid-cols-2 gap-4 rounded-xl border border-[#253247] bg-[#0D1524] p-4 sm:grid-cols-5">
        <div>
          <p className="text-[11px] text-slate-400">Experiment Name</p>
          <p className="mt-1 truncate text-sm font-semibold text-slate-100">
            {targetSession.name}
          </p>
        </div>
        <div>
          <p className="text-[11px] text-slate-400">Duration</p>
          <p className="mt-1 font-mono text-sm font-semibold tabular-nums text-slate-100">
            {formatDuration(targetSession.durationSeconds)}
          </p>
        </div>
        <div>
          <p className="text-[11px] text-slate-400">Samples Recorded</p>
          <p className="mt-1 font-mono text-sm font-semibold tabular-nums text-cyan-400">
            {targetSession.samples.length}
          </p>
        </div>
        <div>
          <p className="text-[11px] text-slate-400">Max Power</p>
          <p className="mt-1 font-mono text-sm font-semibold tabular-nums text-emerald-400">
            {targetSession.peakPowerW.toFixed(precision)} W
          </p>
        </div>
        <div>
          <p className="text-[11px] text-slate-400">Optimal Observed Angle</p>
          <p className="mt-1 font-mono text-sm font-semibold tabular-nums text-[#FACC15]">
            {targetSession.peakObservedAngleDeg !== null
              ? `${targetSession.peakObservedAngleDeg.toFixed(1)}°`
              : '—'}
          </p>
        </div>
      </div>

      {/* Three Export Cards */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        {/* EXPORT A: SESSION VIDEO */}
        <div className="flex flex-col justify-between rounded-xl border border-[#253247] bg-[#111C2D] p-5">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#253247] bg-[#080D18] text-rose-400">
                <Video className="h-5 w-5" aria-hidden="true" />
              </div>
              <span className="font-mono text-xs text-slate-400">{videoFilename}</span>
            </div>

            <h2 className="mt-4 text-base font-semibold text-slate-100">
              Export A: Session Video
            </h2>
            <p className="mt-1.5 text-sm text-slate-400">
              Recorded MediaRecorder video stream of the mirrored Android screen capture
              session.
            </p>

            <div className="mt-4 space-y-1.5 rounded-lg border border-[#253247] bg-[#080D18] p-3 font-mono text-xs text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-500">Status</span>
                <span>
                  {activeVideoBlob
                    ? 'Ready'
                    : targetSession.mode === 'demo'
                    ? 'N/A in Demo Mode'
                    : recordingStatus === 'unsupported'
                    ? 'Unsupported'
                    : 'Not Available'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">MIME Type</span>
                <span className="truncate max-w-[160px]">
                  {activeVideoBlob?.type || recordingMimeType || 'video/webm'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">File Size</span>
                <span className="tabular-nums">
                  {activeVideoBlob
                    ? `${(activeVideoBlob.size / (1024 * 1024)).toFixed(2)} MB`
                    : '—'}
                </span>
              </div>
            </div>

            {recordingError && (
              <p className="mt-2 text-xs text-amber-400">{recordingError}</p>
            )}
          </div>

          <div className="mt-5 space-y-2">
            <button
              type="button"
              onClick={handleDownloadVideo}
              disabled={!activeVideoBlob}
              className="flex w-full items-center justify-center gap-2 rounded-lg border border-rose-500/40 bg-rose-500/15 px-4 py-2.5 text-sm font-semibold text-rose-200 transition-colors hover:bg-rose-500/25 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <Download className="h-4 w-4" aria-hidden="true" />
              <span>Download {videoFilename}</span>
            </button>
            {videoStatus && (
              <p className="flex items-center gap-1.5 text-xs text-emerald-400">
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span>{videoStatus}</span>
              </p>
            )}
          </div>
        </div>

        {/* EXPORT B: CSV DATA */}
        <div className="flex flex-col justify-between rounded-xl border border-[#253247] bg-[#111C2D] p-5">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#253247] bg-[#080D18] text-cyan-400">
                <FileSpreadsheet className="h-5 w-5" aria-hidden="true" />
              </div>
              <span className="font-mono text-xs text-slate-400">
                solar_panel_log.csv
              </span>
            </div>

            <h2 className="mt-4 text-base font-semibold text-slate-100">
              Export B: CSV Telemetry Log
            </h2>
            <p className="mt-1.5 text-sm text-slate-400">
              Complete timestamped experiment dataset formatted with standard scientific
              CSV headers.
            </p>

            <pre className="mt-4 overflow-x-auto rounded-lg border border-[#253247] bg-[#080D18] p-3 font-mono text-[11px] leading-relaxed text-slate-300">
              {csvPreview || 'Time_s,Angle_deg,Voltage_V,Current_A,Power_W'}
            </pre>
          </div>

          <div className="mt-5 space-y-2">
            <button
              type="button"
              onClick={handleDownloadCsv}
              disabled={targetSession.samples.length === 0}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-cyan-500 px-4 py-2.5 text-sm font-semibold text-slate-950 transition-colors hover:bg-cyan-400 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <Download className="h-4 w-4" aria-hidden="true" />
              <span>Download solar_panel_log.csv</span>
            </button>
            {csvStatus && (
              <p className="flex items-center gap-1.5 text-xs text-emerald-400">
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span>{csvStatus}</span>
              </p>
            )}
          </div>
        </div>

        {/* EXPORT C: CHART REPORT */}
        <div className="flex flex-col justify-between rounded-xl border border-[#253247] bg-[#111C2D] p-5">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#253247] bg-[#080D18] text-amber-400">
                <ImageIcon className="h-5 w-5" aria-hidden="true" />
              </div>
              <span className="font-mono text-xs text-slate-400">
                solar_panel_report.png
              </span>
            </div>

            <h2 className="mt-4 text-base font-semibold text-slate-100">
              Export C: Chart Report PNG
            </h2>
            <p className="mt-1.5 text-sm text-slate-400">
              High-resolution 2400 × 1560px composite report including summary KPIs and
              all four synchronized telemetry charts.
            </p>

            <ul className="mt-4 space-y-1.5 rounded-lg border border-[#253247] bg-[#080D18] p-3 text-xs text-slate-300">
              <li>• Header: App name, experiment name, date & duration</li>
              <li>• Metrics: Max power, optimal angle, avg V & avg A</li>
              <li>• Charts: Angle/Time, Voltage/Time, Current/Time, Angle/Power</li>
            </ul>
          </div>

          <div className="mt-5 space-y-2">
            <button
              type="button"
              onClick={handleDownloadPng}
              disabled={pngGenerating || targetSession.samples.length === 0}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#F59E0B] px-4 py-2.5 text-sm font-semibold text-slate-950 transition-colors hover:bg-amber-400 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <Download className="h-4 w-4" aria-hidden="true" />
              <span>
                {pngGenerating
                  ? 'Rendering PNG Report...'
                  : 'Download solar_panel_report.png'}
              </span>
            </button>
            {pngStatus && (
              <p className="flex items-center gap-1.5 text-xs text-emerald-400">
                <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                <span>{pngStatus}</span>
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
