import { ExperimentSession } from '../types/experiment';
import { AppSettings, DEFAULT_APP_SETTINGS } from '../types/telemetry';

const EXPERIMENTS_STORAGE_KEY = 'solar_telemetry_experiments_v1';
const SETTINGS_STORAGE_KEY = 'solar_telemetry_settings_v1';

export interface StorageOperationResult<T> {
  data: T;
  error: string | null;
}

export function loadExperiments(): StorageOperationResult<ExperimentSession[]> {
  try {
    const raw = window.localStorage.getItem(EXPERIMENTS_STORAGE_KEY);
    if (!raw) {
      return { data: [], error: null };
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      return { data: [], error: 'Stored experiment history was corrupted and reset.' };
    }
    return { data: parsed as ExperimentSession[], error: null };
  } catch (err) {
    return {
      data: [],
      error:
        err instanceof Error
          ? `Unable to read local experiment history: ${err.message}`
          : 'Unable to read local experiment history.',
    };
  }
}

export function saveExperiments(
  experiments: ExperimentSession[]
): { error: string | null } {
  try {
    window.localStorage.setItem(
      EXPERIMENTS_STORAGE_KEY,
      JSON.stringify(experiments)
    );
    return { error: null };
  } catch (err) {
    return {
      error:
        err instanceof Error
          ? `Unable to save experiment locally (storage quota or privacy mode): ${err.message}`
          : 'Unable to save experiment to browser local storage.',
    };
  }
}

export function clearStoredExperiments(): { error: string | null } {
  try {
    window.localStorage.removeItem(EXPERIMENTS_STORAGE_KEY);
    return { error: null };
  } catch (err) {
    return {
      error:
        err instanceof Error
          ? `Unable to clear local storage: ${err.message}`
          : 'Unable to clear local storage.',
    };
  }
}

export function loadSettings(): AppSettings {
  try {
    const raw = window.localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_APP_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<AppSettings>;
    return {
      ...DEFAULT_APP_SETTINGS,
      ...parsed,
    };
  } catch {
    return DEFAULT_APP_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): { error: string | null } {
  try {
    window.localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    return { error: null };
  } catch (err) {
    return {
      error:
        err instanceof Error
          ? `Unable to save settings: ${err.message}`
          : 'Unable to save settings.',
    };
  }
}
