const PREFERRED_MIME_TYPES = [
  'video/webm;codecs=vp9',
  'video/webm;codecs=vp8',
  'video/webm',
  'video/mp4',
] as const;

export function isMediaRecorderSupported(): boolean {
  return (
    typeof window !== 'undefined' &&
    typeof MediaRecorder !== 'undefined' &&
    typeof MediaRecorder.isTypeSupported === 'function'
  );
}

/**
 * Selects the best supported MediaRecorder MIME type, preferring WebM
 * and only returning MP4 if MediaRecorder.isTypeSupported reports true.
 */
export function getSupportedRecordingMimeType(): string | null {
  if (!isMediaRecorderSupported()) {
    return null;
  }

  for (const mimeType of PREFERRED_MIME_TYPES) {
    try {
      if (MediaRecorder.isTypeSupported(mimeType)) {
        return mimeType;
      }
    } catch {
      // Continue checking next format
    }
  }

  return '';
}

export function getRecordingFilename(mimeType: string | null): string {
  if (mimeType && mimeType.toLowerCase().includes('mp4')) {
    return 'solar_panel_session.mp4';
  }
  return 'solar_panel_session.webm';
}

export function createRecordingBlob(
  chunks: BlobPart[],
  mimeType: string | null
): Blob | null {
  if (chunks.length === 0) {
    return null;
  }
  const safeType = mimeType && mimeType.length > 0 ? mimeType : 'video/webm';
  return new Blob(chunks, { type: safeType });
}

export function downloadVideoBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
