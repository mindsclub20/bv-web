import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { CheckCircle2, Info, X } from 'lucide-react';
import { Dashboard } from './components/Dashboard';
import { ExperimentHistory } from './components/ExperimentHistory';
import { ExportCenter } from './components/ExportCenter';
import { HeroScreen } from './components/HeroScreen';
import { PerformanceAnalysis } from './components/PerformanceAnalysis';
import { ScreenCapture } from './components/ScreenCapture';
import { SettingsPanel } from './components/SettingsPanel';
import { Sidebar } from './components/Sidebar';
import { Topbar } from './components/Topbar';
import { useDemoSimulator } from './hooks/useDemoSimulator';
import { useExperimentStorage } from './hooks/useExperimentStorage';
import { useMediaRecorder } from './hooks/useMediaRecorder';
import { useRegionSelection } from './hooks/useRegionSelection';
import { useScreenCapture } from './hooks/useScreenCapture';
import { useSolarOCR } from './hooks/useSolarOCR';
import { useTelemetry } from './hooks/useTelemetry';
import { CalibrationRegions } from './types/calibration';
import { ExperimentMode, ExperimentSession } from './types/experiment';
import { AppSection, ConnectionStatus } from './types/telemetry';

function createDefaultSessionName(count: number): string {
  const num = String(count + 1).padStart(2, '0');
  return `Solar Panel Tilt Experiment - Trial ${num}`;
}

export default function App() {
  const {
    experiments,
    storageError,
    settings,
    addOrUpdateExperiment,
    deleteExperiment,
    clearAllExperiments,
    updateSettings,
  } = useExperimentStorage();

  const [activeSection, setActiveSection] = useState<AppSection>('overview');
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);

  const [sessionMode, setSessionMode] = useState<ExperimentMode | null>(null);
  const [sessionId, setSessionId] = useState<string>('');
  const [sessionName, setSessionName] = useState<string>(() =>
    createDefaultSessionName(experiments.length)
  );
  const [sessionStartedAtIso, setSessionStartedAtIso] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  const [calibratedRegions, setCalibratedRegions] =
    useState<CalibrationRegions | null>(null);
  const [lastCompletedSession, setLastCompletedSession] =
    useState<ExperimentSession | null>(null);

  const [notification, setNotification] = useState<{
    message: string;
    tone: 'success' | 'info';
  } | null>(null);

  // Persistent hidden video element for OCR sampling even when user switches tabs
  const ocrVideoRef = useRef<HTMLVideoElement | null>(null);
  const calibrationVideoRef = useRef<HTMLVideoElement | null>(null);

  const telemetry = useTelemetry();
  const recorder = useMediaRecorder();

  const sessionModeRef = useRef(sessionMode);
  sessionModeRef.current = sessionMode;
  const sessionIdRef = useRef(sessionId);
  sessionIdRef.current = sessionId;
  const sessionNameRef = useRef(sessionName);
  sessionNameRef.current = sessionName;
  const sessionStartedRef = useRef(sessionStartedAtIso);
  sessionStartedRef.current = sessionStartedAtIso;
  const elapsedRef = useRef(elapsedSeconds);
  elapsedRef.current = elapsedSeconds;
  const calibratedRegionsRef = useRef(calibratedRegions);
  calibratedRegionsRef.current = calibratedRegions;

  const showToast = useCallback(
    (message: string, tone: 'success' | 'info' = 'success') => {
      setNotification({ message, tone });
    },
    []
  );

  useEffect(() => {
    if (!notification) return;
    const t = window.setTimeout(() => setNotification(null), 6000);
    return () => window.clearTimeout(t);
  }, [notification]);

  // Build snapshot of the current active session
  const buildSessionSnapshot = useCallback(
    (endedIso: string | null = null): ExperimentSession | null => {
      if (!sessionModeRef.current) return null;
      const stats = telemetry.statistics;
      return {
        id: sessionIdRef.current || `exp-${Date.now()}`,
        name: sessionNameRef.current.trim() || 'Solar Panel Tilt Experiment',
        startedAtIso: sessionStartedRef.current || new Date().toISOString(),
        endedAtIso: endedIso,
        durationSeconds: Math.max(elapsedRef.current, stats.durationSeconds),
        mode: sessionModeRef.current,
        calibrationRegions: calibratedRegionsRef.current,
        samples: telemetry.samples,
        peakPowerW: stats.maxPowerW,
        peakObservedAngleDeg: stats.peakObservedAngleDeg,
        averagePowerW: stats.averagePowerW,
        averageVoltageV: stats.averageVoltageV,
        averageCurrentA: stats.averageCurrentA,
        recordingInfo: recorder.getRecordingMetadata(),
      };
    },
    [recorder, telemetry.samples, telemetry.statistics]
  );

  const ocr = useSolarOCR({
    videoRef: ocrVideoRef,
    regions: calibratedRegions,
    isActive: sessionMode === 'real',
    isPaused,
    samplingIntervalMs: settings.ocrIntervalMs,
    contrastThreshold: settings.contrastThreshold,
    invertDisplay: settings.invertDisplay,
    onReadings: telemetry.recordReadings,
  });

  const demo = useDemoSimulator({
    isActive: sessionMode === 'demo',
    isPaused,
    samplingIntervalMs: settings.ocrIntervalMs,
    peakAngleDeg: settings.demoPeakAngleDeg,
    onReadings: telemetry.recordReadings,
  });

  // Handle native browser Stop Sharing button
  const handleNativeStreamEnded = useCallback(async () => {
    const wasRealActive = sessionModeRef.current === 'real';
    if (wasRealActive) {
      const snapshot = buildSessionSnapshot(new Date().toISOString());
      setSessionMode(null);
      setIsPaused(false);
      await ocr.shutdownOCR();
      const finalBlob = await recorder.stopRecording();
      if (snapshot) {
        snapshot.recordingInfo = {
          hasRecording: Boolean(finalBlob && finalBlob.size > 0),
          mimeType: finalBlob?.type || recorder.mimeType,
          sizeBytes: finalBlob?.size ?? 0,
          durationSeconds: recorder.durationSeconds,
          error: recorder.error,
        };
        addOrUpdateExperiment(snapshot);
        setLastCompletedSession(snapshot);
      }
      showToast(
        'Screen sharing stopped. Telemetry and recording preserved — ready in Export Center.',
        'info'
      );
      setActiveSection('reports-exports');
    } else {
      showToast('Screen sharing disconnected.', 'info');
    }
  }, [addOrUpdateExperiment, buildSessionSnapshot, ocr, recorder, showToast]);

  const screenCapture = useScreenCapture({
    onStreamEnded: () => {
      void handleNativeStreamEnded();
    },
  });

  // Keep hidden OCR video element bound to active stream
  useEffect(() => {
    const el = ocrVideoRef.current;
    if (!el) return;
    if (screenCapture.stream) {
      el.srcObject = screenCapture.stream;
      void el.play().catch(() => {});
    } else {
      el.srcObject = null;
    }
  }, [screenCapture.stream]);

  // Automatic transition on 3rd calibration rectangle
  const handleCalibrationComplete = useCallback(
    (regions: CalibrationRegions) => {
      setCalibratedRegions(regions);
      telemetry.resetTelemetry();
      telemetry.startSessionClock();
      ocr.resetDiagnostics();

      const nowIso = new Date().toISOString();
      setSessionId(`exp-${Date.now()}`);
      setSessionStartedAtIso(nowIso);
      setElapsedSeconds(0);
      setIsPaused(false);
      setSessionMode('real');
      setActiveSection('live-monitoring');

      if (screenCapture.stream) {
        recorder.startRecording(screenCapture.stream);
      }

      showToast('Calibration complete. Starting live solar telemetry...', 'success');
    },
    [ocr, recorder, screenCapture.stream, showToast, telemetry]
  );

  const regionSelection = useRegionSelection({
    onComplete: handleCalibrationComplete,
  });

  // Session timer ticking every second while active and not paused
  useEffect(() => {
    if (!sessionMode || isPaused) return;
    const timer = window.setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => window.clearInterval(timer);
  }, [sessionMode, isPaused]);

  const handleSelectMirroredScreen = useCallback(async () => {
    // Clean up any existing demo/real run first
    if (sessionMode === 'real') {
      await ocr.shutdownOCR();
      await recorder.stopRecording();
    }
    setSessionMode(null);
    setIsPaused(false);
    setCalibratedRegions(null);
    regionSelection.resetAll();

    const stream = await screenCapture.startCapture();
    if (stream) {
      setSessionName(createDefaultSessionName(experiments.length));
      setActiveSection('screen-calibration');
    }
  }, [experiments.length, ocr, recorder, regionSelection, screenCapture, sessionMode]);

  const handleStartDemoSimulator = useCallback(async () => {
    if (sessionMode === 'real') {
      await ocr.shutdownOCR();
      await recorder.stopRecording();
      screenCapture.stopCapture();
    }
    recorder.resetRecording();
    telemetry.resetTelemetry();
    telemetry.startSessionClock();
    demo.resetSimulator();

    setCalibratedRegions(null);
    regionSelection.resetAll();
    setSessionId(`demo-${Date.now()}`);
    setSessionName(createDefaultSessionName(experiments.length));
    setSessionStartedAtIso(new Date().toISOString());
    setElapsedSeconds(0);
    setIsPaused(false);
    setSessionMode('demo');
    setActiveSection('live-monitoring');
    showToast('Demo Simulator started with live solar power modeling.', 'info');
  }, [
    demo,
    experiments.length,
    ocr,
    recorder,
    regionSelection,
    screenCapture,
    sessionMode,
    showToast,
    telemetry,
  ]);

  // ?autostart=1 support for automated testing / quick launch
  const autostartTriggeredRef = useRef(false);
  useEffect(() => {
    if (autostartTriggeredRef.current) return;
    autostartTriggeredRef.current = true;
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      void handleStartDemoSimulator();
    }
  }, [handleStartDemoSimulator]);

  const handlePauseMonitoring = useCallback(() => {
    setIsPaused(true);
  }, []);

  const handleResumeMonitoring = useCallback(() => {
    setIsPaused(false);
  }, []);

  const handleRedrawBoxes = useCallback(async () => {
    setSessionMode(null);
    setIsPaused(false);
    await ocr.shutdownOCR();
    await recorder.stopRecording();
    setCalibratedRegions(null);
    regionSelection.resetAll();
    setActiveSection('screen-calibration');
  }, [ocr, recorder, regionSelection]);

  const handleStopAndExport = useCallback(async () => {
    const activeMode = sessionModeRef.current;
    const snapshot = buildSessionSnapshot(new Date().toISOString());
    setSessionMode(null);
    setIsPaused(false);

    if (activeMode === 'real') {
      await ocr.shutdownOCR();
    }
    const finalBlob = await recorder.stopRecording();

    if (snapshot) {
      if (activeMode === 'real') {
        snapshot.recordingInfo = {
          hasRecording: Boolean(finalBlob && finalBlob.size > 0),
          mimeType: finalBlob?.type || recorder.mimeType,
          sizeBytes: finalBlob?.size ?? 0,
          durationSeconds: recorder.durationSeconds,
          error: recorder.error,
        };
      }
      addOrUpdateExperiment(snapshot);
      setLastCompletedSession(snapshot);
    }

    setActiveSection('reports-exports');
    showToast('Monitoring stopped. Session saved to Experiment History.', 'success');
  }, [addOrUpdateExperiment, buildSessionSnapshot, ocr, recorder, showToast]);

  const connectionStatus: ConnectionStatus = useMemo(() => {
    if (screenCapture.isRequesting) return 'requesting';
    if (screenCapture.error && !screenCapture.stream && !sessionMode) return 'error';
    if (sessionMode === 'demo') return isPaused ? 'paused' : 'demo';
    if (sessionMode === 'real') return isPaused ? 'paused' : 'monitoring';
    if (screenCapture.stream) {
      return activeSection === 'screen-calibration' ? 'calibrating' : 'connected';
    }
    return 'disconnected';
  }, [
    activeSection,
    isPaused,
    screenCapture.error,
    screenCapture.isRequesting,
    screenCapture.stream,
    sessionMode,
  ]);

  const liveOrLatestSession = useMemo(() => {
    if (sessionMode && telemetry.samples.length > 0) {
      return buildSessionSnapshot(null);
    }
    return lastCompletedSession ?? experiments[0] ?? null;
  }, [
    buildSessionSnapshot,
    experiments,
    lastCompletedSession,
    sessionMode,
    telemetry.samples.length,
  ]);

  return (
    <div
      className="flex h-screen w-screen overflow-hidden bg-[#080D18] text-slate-100"
      data-app-mode={sessionMode ?? 'idle'}
      data-active-section={activeSection}
    >
      {/* Persistent off-screen video element for OCR sampling */}
      <video
        ref={ocrVideoRef}
        autoPlay
        playsInline
        muted
        aria-hidden="true"
        className="pointer-events-none fixed -left-[9999px] top-0 h-1 w-1 opacity-0"
      />

      <Sidebar
        activeSection={activeSection}
        onSelectSection={setActiveSection}
        hasActiveSession={sessionMode !== null}
        experimentCount={experiments.length}
        isOpenMobile={isMobileNavOpen}
        onCloseMobile={() => setIsMobileNavOpen(false)}
      />

      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <Topbar
          sessionName={sessionName}
          onSessionNameChange={setSessionName}
          connectionStatus={connectionStatus}
          elapsedSeconds={elapsedSeconds}
          recordingStatus={recorder.status}
          recordingDurationSeconds={recorder.durationSeconds}
          onOpenSettings={() => setActiveSection('settings')}
          onOpenMobileNav={() => setIsMobileNavOpen(true)}
        />

        {notification && (
          <div
            className={`flex items-center justify-between gap-3 border-b px-6 py-2.5 text-xs font-medium ${
              notification.tone === 'success'
                ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200'
                : 'border-cyan-500/30 bg-cyan-500/10 text-cyan-200'
            }`}
            role="status"
          >
            <div className="flex items-center gap-2">
              {notification.tone === 'success' ? (
                <CheckCircle2 className="h-4 w-4 text-emerald-400" aria-hidden="true" />
              ) : (
                <Info className="h-4 w-4 text-cyan-400" aria-hidden="true" />
              )}
              <span>{notification.message}</span>
            </div>
            <button
              type="button"
              onClick={() => setNotification(null)}
              className="rounded p-1 hover:bg-white/10"
              aria-label="Dismiss notification"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        <main className="flex-1 overflow-y-auto bg-[#080D18]">
          {activeSection === 'overview' && (
            <HeroScreen
              onSelectScreen={() => void handleSelectMirroredScreen()}
              onStartDemo={() => void handleStartDemoSimulator()}
              onViewHistory={() => setActiveSection('experiment-history')}
              experimentCount={experiments.length}
              isRequestingScreen={screenCapture.isRequesting}
              screenError={screenCapture.error}
            />
          )}

          {activeSection === 'live-monitoring' && (
            <Dashboard
              mode={sessionMode}
              isPaused={isPaused}
              samples={telemetry.samples}
              angleState={telemetry.angleState}
              voltageState={telemetry.voltageState}
              currentState={telemetry.currentState}
              currentPowerW={telemetry.currentPowerW}
              statistics={telemetry.statistics}
              elapsedSeconds={elapsedSeconds}
              settings={settings}
              ocrDiagnostics={ocr.diagnostics}
              recordingStatus={recorder.status}
              recordingDurationSeconds={recorder.durationSeconds}
              recordingError={recorder.error}
              stream={screenCapture.stream}
              onPause={handlePauseMonitoring}
              onResume={handleResumeMonitoring}
              onToggleInvert={() =>
                updateSettings({ invertDisplay: !settings.invertDisplay })
              }
              onContrastChange={(val) =>
                updateSettings({ contrastThreshold: val })
              }
              onRedrawBoxes={() => void handleRedrawBoxes()}
              onStopAndExport={() => void handleStopAndExport()}
              onSelectScreen={() => void handleSelectMirroredScreen()}
              onStartDemo={() => void handleStartDemoSimulator()}
            />
          )}

          {activeSection === 'screen-calibration' && (
            <ScreenCapture
              stream={screenCapture.stream}
              videoRef={calibrationVideoRef}
              videoDimensions={screenCapture.videoDimensions}
              trackLabel={screenCapture.trackLabel}
              isSupported={screenCapture.isSupported}
              isRequesting={screenCapture.isRequesting}
              error={screenCapture.error}
              onStartCapture={() => void handleSelectMirroredScreen()}
              onStopCapture={() => {
                screenCapture.stopCapture();
                regionSelection.resetAll();
              }}
              onStartDemo={() => void handleStartDemoSimulator()}
              onVideoMetadata={screenCapture.updateVideoMetadataDimensions}
              regions={regionSelection.regions}
              currentStepIndex={regionSelection.currentStepIndex}
              activeStepConfig={regionSelection.activeStepConfig}
              activeDraftRect={regionSelection.activeDraftRect}
              validationMessage={regionSelection.validationMessage}
              onPointerDown={regionSelection.handlePointerDown}
              onPointerMove={regionSelection.handlePointerMove}
              onPointerUp={regionSelection.handlePointerUp}
              onUndo={regionSelection.undoLast}
              onReset={regionSelection.resetAll}
            />
          )}

          {activeSection === 'experiment-history' && (
            <ExperimentHistory
              experiments={experiments}
              storageError={storageError}
              precision={settings.numericPrecision}
              onDeleteExperiment={deleteExperiment}
              onOpenInAnalysis={() => setActiveSection('performance-analysis')}
            />
          )}

          {activeSection === 'performance-analysis' && (
            <PerformanceAnalysis
              activeSession={liveOrLatestSession}
              experiments={experiments}
              defaultIntervalDeg={settings.angleBinIntervalDeg}
              precision={settings.numericPrecision}
            />
          )}

          {activeSection === 'reports-exports' && (
            <ExportCenter
              session={lastCompletedSession ?? liveOrLatestSession}
              experiments={experiments}
              recordedBlob={recorder.recordedBlob}
              recordingMimeType={recorder.mimeType}
              recordingStatus={recorder.status}
              recordingError={recorder.error}
              precision={settings.numericPrecision}
            />
          )}

          {activeSection === 'settings' && (
            <SettingsPanel
              settings={settings}
              experimentCount={experiments.length}
              onUpdateSettings={updateSettings}
              onClearHistory={clearAllExperiments}
            />
          )}
        </main>
      </div>
    </div>
  );
}
